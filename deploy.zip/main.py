from fastapi import FastAPI, HTTPException, Depends
from fastapi.responses import StreamingResponse
import io, requests as req_http
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel
from typing import List, Optional
from supabase import create_client
from passlib.context import CryptContext
from jose import jwt, JWTError
from datetime import datetime, timedelta
from dotenv import load_dotenv
import os
import time
from datetime import datetime, timedelta

# ── Sesiones DWG activas (en memoria) ─────────────────────────────────────────
# { contrato_id: timestamp_ultimo_heartbeat }
_dwg_sessions: dict = {}
_DWG_TIMEOUT = 30  # segundos — margen para curl.exe

def _dwg_activo(contrato_id: int, usuario_id: int = None) -> bool:
    """Verifica si hay un DWG enlazado para el contrato, por usuario o cualquier usuario."""
    if usuario_id and _dwg_sessions.get((contrato_id, usuario_id)):
        ts = _dwg_sessions[(contrato_id, usuario_id)]
        return (time.time() - ts) < _DWG_TIMEOUT
    # Fallback: cualquier usuario del contrato con sesión activa
    for k, ts in _dwg_sessions.items():
        if isinstance(k, tuple) and k[0] == contrato_id and (time.time() - ts) < _DWG_TIMEOUT:
            return True
    return False

load_dotenv()

app = FastAPI(title="ClaraCore API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "https://claracore.co",
        "https://www.claracore.co",
        "http://localhost:5173",
        "http://localhost:5174",
    ],
    allow_methods=["*"],
    allow_headers=["*"],
    allow_credentials=True,
)

supabase = create_client(os.getenv("SUPABASE_URL"), os.getenv("SUPABASE_KEY"))
security = HTTPBearer()

SECRET_KEY = os.getenv("SECRET_KEY")
ALGORITHM = os.getenv("ALGORITHM")
EXPIRE_MINUTES = int(os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES"))

# ─────────────────────────────────────────────
# MODELOS
# ─────────────────────────────────────────────

class LoginRequest(BaseModel):
    email: str
    password: str

class UsuarioCreate(BaseModel):
    nombre: str
    email: str
    password: str
    cargo_id: int

class UsuarioRegistro(BaseModel):
    nombre: str
    apellidos: str
    email: str
    cargo_id: int
    contrato_id: Optional[int] = None
    password: str

class AprobarRequest(BaseModel):
    rol_id: int

class CargoCreate(BaseModel):
    nombre: str
    rol_id: Optional[int] = None
    categoria_id: Optional[int] = None

class ContratoCreate(BaseModel):
    numero: str
    objeto: Optional[str] = None
    contratista: Optional[str] = None
    nit: Optional[str] = None
    interventoria: Optional[str] = None
    logo_contratista: Optional[str] = None
    logo_interventoria: Optional[str] = None

class PermisoUpdate(BaseModel):
    cargo_id: int
    funcion_id: int
    ver: bool = False
    crear: bool = False
    editar: bool = False
    eliminar: bool = False
    validar: bool = False
    exportar: bool = False

class UsuarioUpdate(BaseModel):
    cargo_id: Optional[int] = None
    rol_id: Optional[int] = None
    contrato_id: Optional[int] = None
    estado: Optional[str] = None

class UsuarioContratoCreate(BaseModel):
    usuario_id: int
    contrato_id: int

class ContratoUpdate(BaseModel):
    numero: Optional[str] = None
    objeto: Optional[str] = None
    contratista: Optional[str] = None
    nit: Optional[str] = None
    interventoria: Optional[str] = None
    logo_contratista: Optional[str] = None
    logo_interventoria: Optional[str] = None
    fase: Optional[str] = None  # 'PRESUPUESTO' | 'LIQUIDACION'

class ListadoPrecioItem(BaseModel):
    capitulo: Optional[str] = None
    competencia: Optional[str] = None
    item_numero: Optional[str] = None
    descripcion: Optional[str] = None
    unidad: Optional[str] = None
    precio_unitario: Optional[float] = None
    color_hex: Optional[str] = None

class PresupuestoRow(BaseModel):
    pk_id: Optional[str] = None
    capitulo: Optional[str] = None
    competencia: Optional[str] = None
    item: Optional[str] = None
    descripcion: Optional[str] = None
    und: Optional[str] = None
    calzada: Optional[str] = None
    tramo: Optional[str] = None
    abs_inicio: Optional[str] = None
    abs_final: Optional[str] = None
    vlr_unitario: Optional[float] = None
    no_inicio: Optional[str] = None
    no_final: Optional[str] = None
    area_long_nod: Optional[float] = None
    ancho: Optional[float] = None
    espesor: Optional[float] = None
    cant_total: Optional[float] = None
    costo_directo: Optional[float] = None
    tipo_ejecucion: Optional[str] = None
    tipo_entidad: Optional[str] = None
    id_pol: Optional[str] = None
    observacion: Optional[str] = None
    revisado: Optional[str] = None
    observacion_externa: Optional[str] = None
    ent_handle: Optional[str] = None
    txt_handle: Optional[str] = None
    layer_ent: Optional[str] = None
    layer_txt: Optional[str] = None
    color_hex: Optional[str] = None
    guid: Optional[str] = None
    x_label: Optional[float] = None
    y_label: Optional[float] = None

class PresupuestoUpdate(BaseModel):
    capitulo: Optional[str] = None
    competencia: Optional[str] = None
    item: Optional[str] = None
    descripcion: Optional[str] = None
    und: Optional[str] = None
    calzada: Optional[str] = None
    tramo: Optional[str] = None
    vlr_unitario: Optional[float] = None
    area_long_nod: Optional[float] = None
    ancho: Optional[float] = None
    espesor: Optional[float] = None
    cant_total: Optional[float] = None
    costo_directo: Optional[float] = None
    revisado: Optional[str] = None
    observacion_externa: Optional[str] = None

class DimOverride(BaseModel):
    id: int
    ancho: Optional[float] = None
    espesor: Optional[float] = None

class PresupuestoBulkRecalc(BaseModel):
    ids: List[int]
    capitulo: Optional[str] = None
    item: Optional[str] = None
    descripcion: Optional[str] = None
    vlr_unitario: Optional[float] = None
    dims: Optional[List[DimOverride]] = None  # cambios de dimensión por fila

class PresupuestoBulkEstado(BaseModel):
    ids: List[int]
    revisado: str

class CadQueueCreate(BaseModel):
    tipo: str        # cambiar_layer | insertar_bloque
    payload: dict

class CadQueueProcesado(BaseModel):
    rev_block_handle: Optional[str] = None   # solo para insertar_bloque
    presupuesto_id:   Optional[int] = None

class CobroRow(BaseModel):
    pk_id: Optional[str] = None
    acta: Optional[int] = None
    semana: Optional[str] = None
    fecha: Optional[str] = None
    capitulo: Optional[str] = None
    competencia: Optional[str] = None
    abs_inicial: Optional[str] = None
    abs_final: Optional[str] = None
    civ: Optional[str] = None
    item: Optional[str] = None
    descripcion: Optional[str] = None
    und: Optional[str] = None
    longitud: Optional[float] = None
    ancho: Optional[float] = None
    espesor: Optional[float] = None
    cantidad: Optional[float] = None
    valor_unitario: Optional[float] = None
    costo_directo: Optional[float] = None
    calzada: Optional[str] = None
    tramo_inicio: Optional[str] = None
    tramo_final: Optional[str] = None
    registro: Optional[str] = None
    tramo: Optional[str] = None
    observaciones: Optional[str] = None

class ResetSolicitud(BaseModel):
    email: str

class ResetAutorizar(BaseModel):
    contrasena_temporal: str

class CambiarPassword(BaseModel):
    email: str
    contrasena_temporal: str
    nueva_password: str

# ─────────────────────────────────────────────
# SISTEMA DE LOGS
# ─────────────────────────────────────────────
def registrar_log(usuario, accion, modulo, entidad_tipo=None, entidad_id=None, detalle=None, resultado="ok"):
    try:
        uid = usuario.get("sub") or usuario.get("id")
        supabase.table("logs").insert({
            "usuario_id":      int(uid) if uid else None,
            "usuario_nombre":  usuario.get("nombre") or usuario.get("email", ""),
            "cargo_nombre":    usuario.get("cargo_nombre", ""),
            "contrato_id":     usuario.get("contrato_id"),
            "contrato_numero": usuario.get("contrato_numero"),
            "accion":          accion,
            "modulo":          modulo,
            "entidad_tipo":    entidad_tipo,
            "entidad_id":      str(entidad_id) if entidad_id is not None else None,
            "detalle":         detalle or {},
            "resultado":       resultado,
        }).execute()
    except Exception:
        pass

# ─────────────────────────────────────────────
# SEGURIDAD
# ─────────────────────────────────────────────

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

def hash_password(password: str):
    return pwd_context.hash(password)

def verify_password(plain: str, hashed: str):
    return pwd_context.verify(plain, hashed)

def create_token(data: dict):
    payload = data.copy()
    payload.update({"exp": datetime.utcnow() + timedelta(minutes=EXPIRE_MINUTES)})
    return jwt.encode(payload, SECRET_KEY, algorithm=ALGORITHM)

def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)):
    try:
        payload = jwt.decode(credentials.credentials, SECRET_KEY, algorithms=[ALGORITHM])
        return payload
    except JWTError:
        raise HTTPException(status_code=401, detail="Token inválido")

# ─────────────────────────────────────────────
# RUTAS PÚBLICAS
# ─────────────────────────────────────────────

@app.get("/")
def root():
    return {"message": "ClaraCore API funcionando"}

@app.get("/cargos")
def listar_cargos():
    return supabase.table("cargos").select("*").order("nombre").execute().data

@app.get("/roles")
def listar_roles():
    return supabase.table("roles").select("*").order("nombre").execute().data

@app.get("/contratos")
def listar_contratos():
    return supabase.table("contratos").select("id, numero, objeto, contratista, nit, interventoria, logo_contratista, logo_interventoria, fase").order("numero").execute().data

@app.post("/auth/login")
def login(request: LoginRequest):
    result = supabase.table("usuarios").select("*").eq("email", request.email).execute()
    if not result.data:
        raise HTTPException(status_code=401, detail="Usuario no encontrado")
    usuario = result.data[0]
    if not verify_password(request.password, usuario["password_hash"]):
        raise HTTPException(status_code=401, detail="Contraseña incorrecta")
    if usuario.get("estado") == "pendiente":
        raise HTTPException(status_code=403, detail="Tu cuenta está pendiente de aprobación")
    if usuario.get("estado") == "rechazado":
        raise HTTPException(status_code=403, detail="Tu cuenta fue rechazada")

    cargo_nombre = None
    if usuario.get("cargo_id"):
        r = supabase.table("cargos").select("nombre").eq("id", usuario["cargo_id"]).execute()
        if r.data: cargo_nombre = r.data[0]["nombre"]

    rol_nombre = None
    if usuario.get("rol_id"):
        r = supabase.table("roles").select("nombre").eq("id", usuario["rol_id"]).execute()
        if r.data: rol_nombre = r.data[0]["nombre"]

    contrato_numero = None
    logo_contratista = None
    logo_interventoria = None
    if usuario.get("contrato_id"):
        r = supabase.table("contratos").select("numero, logo_contratista, logo_interventoria").eq("id", usuario["contrato_id"]).execute()
        if r.data:
            contrato_numero = r.data[0]["numero"]
            logo_contratista = r.data[0].get("logo_contratista")
            logo_interventoria = r.data[0].get("logo_interventoria")

    token = create_token({"sub": str(usuario["id"]), "email": usuario["email"]})

    # Cargar permisos del cargo para control de acceso en el panel
    permisos = []
    if usuario.get("cargo_id"):
        permisos_raw = supabase.table("permisos").select("*").eq("cargo_id", usuario["cargo_id"]).execute().data
        funciones_map = {f["id"]: f["nombre"] for f in supabase.table("funciones").select("id, nombre").execute().data}
        permisos = [{**p, "funcion_nombre": funciones_map.get(p["funcion_id"], "")} for p in permisos_raw]

    registrar_log(
        {"sub": str(usuario["id"]), "nombre": usuario.get("nombre",""),
         "cargo_nombre": cargo_nombre, "contrato_id": usuario.get("contrato_id"),
         "contrato_numero": contrato_numero},
        "LOGIN", "AUTH", "usuario", str(usuario["id"]),
        {"email": usuario["email"], "cargo": cargo_nombre, "contrato": contrato_numero}
    )

    return {
        "access_token": token,
        "token_type": "bearer",
        "usuario": {
            "id": usuario["id"],
            "nombre": usuario["nombre"],
            "apellidos": usuario.get("apellidos"),
            "email": usuario["email"],
            "cargo_id": usuario.get("cargo_id"),
            "cargo_nombre": cargo_nombre,
            "rol_id": usuario.get("rol_id"),
            "rol_nombre": rol_nombre,
            "contrato_id": usuario.get("contrato_id"),
            "contrato_numero": contrato_numero,
            "logo_contratista": logo_contratista,
            "logo_interventoria": logo_interventoria,
            "estado": usuario.get("estado"),
            "activo": usuario.get("activo"),
            "permisos": permisos,
        }
    }

@app.post("/usuarios/registro")
def registro_usuario(usuario: UsuarioRegistro):
    existe = supabase.table("usuarios").select("id").eq("email", usuario.email).execute()
    if existe.data:
        raise HTTPException(status_code=400, detail="Este correo ya está registrado")
    hashed = hash_password(usuario.password)
    supabase.table("usuarios").insert({
        "nombre": usuario.nombre,
        "apellidos": usuario.apellidos,
        "email": usuario.email,
        "password_hash": hashed,
        "cargo_id": usuario.cargo_id,
        "contrato_id": usuario.contrato_id,
        "activo": False,
        "estado": "pendiente"
    }).execute()
    return {"mensaje": "Registro exitoso, pendiente de aprobación"}

# ─────────────────────────────────────────────
# RUTAS AUTENTICADAS
# ─────────────────────────────────────────────

@app.get("/usuarios/me")
def get_mi_usuario(current_user=Depends(get_current_user)):
    """Devuelve el perfil actualizado del usuario en sesión. Usado para polling de sesión en tiempo real."""
    uid = int(current_user["sub"])
    result = supabase.table("usuarios").select("*").eq("id", uid).execute()
    if not result.data:
        raise HTTPException(status_code=404, detail="Usuario no encontrado")
    u = result.data[0]
    cargo_nombre = None
    if u.get("cargo_id"):
        r = supabase.table("cargos").select("nombre").eq("id", u["cargo_id"]).execute()
        if r.data: cargo_nombre = r.data[0]["nombre"]
    rol_nombre = None
    if u.get("rol_id"):
        r = supabase.table("roles").select("nombre").eq("id", u["rol_id"]).execute()
        if r.data: rol_nombre = r.data[0]["nombre"]
    permisos = []
    if u.get("cargo_id"):
        permisos_raw = supabase.table("permisos").select("*").eq("cargo_id", u["cargo_id"]).execute().data
        funciones_map = {f["id"]: f["nombre"] for f in supabase.table("funciones").select("id, nombre").execute().data}
        permisos = [{**p, "funcion_nombre": funciones_map.get(p["funcion_id"], "")} for p in permisos_raw]
    return {
        "id": u["id"], "nombre": u["nombre"], "apellidos": u.get("apellidos"),
        "email": u["email"], "cargo_id": u.get("cargo_id"), "cargo_nombre": cargo_nombre,
        "rol_id": u.get("rol_id"), "rol_nombre": rol_nombre,
        "contrato_id": u.get("contrato_id"), "estado": u.get("estado"), "activo": u.get("activo"),
        "permisos": permisos,
    }

@app.get("/usuarios")
def listar_usuarios(current_user=Depends(get_current_user)):
    return supabase.table("usuarios").select(
        "id, nombre, apellidos, email, activo, cargo_id, rol_id, contrato_id, estado, created_at"
    ).execute().data

@app.post("/usuarios")
def crear_usuario(usuario: UsuarioCreate, current_user=Depends(get_current_user)):
    hashed = hash_password(usuario.password)
    return supabase.table("usuarios").insert({
        "nombre": usuario.nombre,
        "email": usuario.email,
        "password_hash": hashed,
        "cargo_id": usuario.cargo_id
    }).execute().data

@app.get("/categorias")
def listar_categorias(current_user=Depends(get_current_user)):
    return supabase.table("categorias").select("*").execute().data

@app.get("/funciones")
def listar_funciones(current_user=Depends(get_current_user)):
    return supabase.table("funciones").select("*").order("nombre").execute().data

@app.post("/contratos")
def crear_contrato(contrato: ContratoCreate, current_user=Depends(get_current_user)):
    existe = supabase.table("contratos").select("id").eq("numero", contrato.numero).execute()
    if existe.data:
        raise HTTPException(status_code=400, detail="Ya existe un contrato con ese número")
    result = supabase.table("contratos").insert({
        "numero": contrato.numero,
        "objeto": contrato.objeto,
        "contratista": contrato.contratista,
        "nit": contrato.nit,
        "interventoria": contrato.interventoria,
        "logo_contratista": contrato.logo_contratista,
        "logo_interventoria": contrato.logo_interventoria,
    }).execute()
    return result.data[0]

@app.put("/contratos/{contrato_id}")
def actualizar_contrato(contrato_id: int, body: ContratoUpdate, current_user=Depends(get_current_user)):
    data = body.dict(exclude_unset=True)
    if not data:
        return {"mensaje": "Sin cambios"}
    supabase.table("contratos").update(data).eq("id", contrato_id).execute()
    return {"mensaje": "Contrato actualizado"}

@app.delete("/contratos/{contrato_id}")
def eliminar_contrato(contrato_id: int, current_user=Depends(get_current_user)):
    supabase.table("contratos").delete().eq("id", contrato_id).execute()
    return {"mensaje": "Contrato eliminado"}
# ─────────────────────────────────────────────
# RUTAS ADMIN
# ─────────────────────────────────────────────

@app.get("/admin/usuarios-pendientes")
def usuarios_pendientes(current_user=Depends(get_current_user)):
    result = supabase.table("usuarios").select(
        "id, nombre, apellidos, email, cargo_id, contrato_id, estado, created_at"
    ).eq("estado", "pendiente").execute()

    cargos = {c["id"]: c["nombre"] for c in supabase.table("cargos").select("id, nombre").execute().data}
    contratos = {c["id"]: c["numero"] for c in supabase.table("contratos").select("id, numero").execute().data}
    for u in result.data:
        u["cargo_nombre"] = cargos.get(u.get("cargo_id"), "Sin cargo")
        u["contrato_numero"] = contratos.get(u.get("contrato_id"), "Sin contrato")
    return result.data

@app.put("/admin/usuarios/{usuario_id}/aprobar")
def aprobar_usuario(usuario_id: int, body: AprobarRequest, current_user=Depends(get_current_user)):
    supabase.table("usuarios").update({
        "estado": "aprobado", "activo": True, "rol_id": body.rol_id
    }).eq("id", usuario_id).execute()
    rol_nombre = ""
    if body.rol_id:
        r = supabase.table("roles").select("nombre").eq("id", body.rol_id).execute()
        rol_nombre = r.data[0]["nombre"] if r.data else str(body.rol_id)
    registrar_log(current_user, "APROBAR", "USUARIOS", "usuario", str(usuario_id),
        {"estado": "aprobado", "rol": rol_nombre})
    return {"mensaje": "Usuario aprobado"}

@app.put("/admin/usuarios/{usuario_id}/rechazar")
def rechazar_usuario(usuario_id: int, current_user=Depends(get_current_user)):
    supabase.table("usuarios").update({
        "estado": "rechazado", "activo": False
    }).eq("id", usuario_id).execute()
    registrar_log(current_user, "RECHAZAR", "USUARIOS", "usuario", str(usuario_id),
        {"estado": "rechazado"})
    return {"mensaje": "Usuario rechazado"}

@app.post("/admin/cargos")
def crear_cargo(cargo: CargoCreate, current_user=Depends(get_current_user)):
    return supabase.table("cargos").insert({
        "nombre": cargo.nombre, "rol_id": cargo.rol_id, "categoria_id": cargo.categoria_id
    }).execute().data

@app.delete("/admin/cargos/{cargo_id}")
def eliminar_cargo(cargo_id: int, current_user=Depends(get_current_user)):
    supabase.table("cargos").delete().eq("id", cargo_id).execute()
    return {"mensaje": "Cargo eliminado"}

@app.get("/admin/permisos/{cargo_id}")
def obtener_permisos(cargo_id: int, current_user=Depends(get_current_user)):
    return supabase.table("permisos").select("*").eq("cargo_id", cargo_id).execute().data

@app.get("/admin/todos-usuarios")
def todos_usuarios(current_user=Depends(get_current_user)):
    result = supabase.table("usuarios").select(
        "id, nombre, apellidos, email, activo, cargo_id, rol_id, contrato_id, estado, created_at"
    ).order("nombre").execute()
    cargos = {c["id"]: c["nombre"] for c in supabase.table("cargos").select("id, nombre").execute().data}
    roles = {r["id"]: r["nombre"] for r in supabase.table("roles").select("id, nombre").execute().data}
    contratos = {c["id"]: c["numero"] for c in supabase.table("contratos").select("id, numero").execute().data}
    for u in result.data:
        u["cargo_nombre"] = cargos.get(u.get("cargo_id"), "Sin cargo")
        u["rol_nombre"] = roles.get(u.get("rol_id"), "Sin rol")
        u["contrato_numero"] = contratos.get(u.get("contrato_id"), "Sin contrato")
    # Desarrollador es invisible para otros cargos, pero visible para sí mismo
        caller_id = int(current_user["sub"])
        # Obtener datos del caller para saber su cargo y contrato
        caller_data = supabase.table("usuarios").select("cargo_id, contrato_id").eq("id", caller_id).execute().data
        caller_cargo = ""
        caller_contrato = None
        if caller_data:
            cid = caller_data[0].get("cargo_id")
            if cid:
                c = supabase.table("cargos").select("nombre").eq("id", cid).execute().data
                if c: caller_cargo = c[0]["nombre"].lower()
            caller_contrato = caller_data[0].get("contrato_id")

            # Paso 1: filtro por contrato si es Administrador
            if caller_cargo == "administrador" and caller_contrato:
                filtered = [u for u in result.data if u.get("contrato_id") == caller_contrato]
            else:
                filtered = list(result.data)

            # Paso 2: Desarrollador siempre invisible para todos, excepto para sí mismo
            filtered = [u for u in filtered if u.get("cargo_nombre", "").lower() != "desarrollador" or u["id"] == caller_id]

            return filtered

@app.put("/admin/usuarios/{usuario_id}")
def actualizar_usuario(usuario_id: int, body: UsuarioUpdate, current_user=Depends(get_current_user)):
    # Proteger: no se puede modificar un Desarrollador SALVO que sea él mismo editándose
    es_el_mismo = str(usuario_id) == str(current_user.get("sub"))
    if not es_el_mismo:
        target = supabase.table("usuarios").select("cargo_id").eq("id", usuario_id).execute()
        if target.data and target.data[0].get("cargo_id"):
            cargo_res = supabase.table("cargos").select("nombre").eq("id", target.data[0]["cargo_id"]).execute()
            if cargo_res.data and cargo_res.data[0]["nombre"].lower() == "desarrollador":
                raise HTTPException(status_code=403, detail="No se puede modificar un usuario Desarrollador")
    # exclude_unset=True: campos no enviados no se tocan; null explícito sí borra el campo
    data = body.dict(exclude_unset=True)
    if body.estado == "aprobado":
        data["activo"] = True
    elif body.estado == "rechazado":
        data["activo"] = False
    supabase.table("usuarios").update(data).eq("id", usuario_id).execute()
    # Enriquecer detalle con nombres legibles
    detalle_log = dict(data)
    if "cargo_id" in detalle_log:
        r = supabase.table("cargos").select("nombre").eq("id", detalle_log["cargo_id"]).execute()
        detalle_log["cargo"] = r.data[0]["nombre"] if r.data else str(detalle_log["cargo_id"])
        del detalle_log["cargo_id"]
    if "rol_id" in detalle_log:
        r = supabase.table("roles").select("nombre").eq("id", detalle_log["rol_id"]).execute()
        detalle_log["rol"] = r.data[0]["nombre"] if r.data else str(detalle_log["rol_id"])
        del detalle_log["rol_id"]
    if "contrato_id" in detalle_log:
        r = supabase.table("contratos").select("numero").eq("id", detalle_log["contrato_id"]).execute()
        detalle_log["contrato"] = r.data[0]["numero"] if r.data else str(detalle_log["contrato_id"])
        del detalle_log["contrato_id"]
    registrar_log(current_user, "EDITAR", "USUARIOS", "usuario", str(usuario_id), detalle_log)
    return {"mensaje": "Usuario actualizado"}

@app.get("/admin/usuario-contratos/{usuario_id}")
def get_usuario_contratos(usuario_id: int, current_user=Depends(get_current_user)):
    result = supabase.table("usuario_contratos").select("contrato_id").eq("usuario_id", usuario_id).execute()
    ids = [r["contrato_id"] for r in result.data]
    if not ids:
        return []
    contratos = supabase.table("contratos").select("id, numero, contratista, interventoria, logo_contratista, logo_interventoria, fase").in_("id", ids).execute()
    return contratos.data

@app.post("/admin/usuario-contratos")
def agregar_usuario_contrato(body: UsuarioContratoCreate, current_user=Depends(get_current_user)):
    existe = supabase.table("usuario_contratos").select("id").eq("usuario_id", body.usuario_id).eq("contrato_id", body.contrato_id).execute()
    if existe.data:
        raise HTTPException(status_code=400, detail="El usuario ya tiene ese contrato asignado")
    supabase.table("usuario_contratos").insert({"usuario_id": body.usuario_id, "contrato_id": body.contrato_id}).execute()
    return {"mensaje": "Contrato asignado"}

@app.delete("/admin/usuario-contratos/{usuario_id}/{contrato_id}")
def quitar_usuario_contrato(usuario_id: int, contrato_id: int, current_user=Depends(get_current_user)):
    supabase.table("usuario_contratos").delete().eq("usuario_id", usuario_id).eq("contrato_id", contrato_id).execute()
    return {"mensaje": "Contrato removido"}

@app.post("/auth/refresh")
def refresh_token(current_user=Depends(get_current_user)):
    """Renueva el token JWT del usuario activo."""
    new_token = create_token({
        "sub": current_user.get("sub"),
        "email": current_user.get("email")
    })
    return {"access_token": new_token, "token_type": "bearer"}

@app.post("/auth/solicitar-reset")
def solicitar_reset(body: ResetSolicitud):
    usuario = supabase.table("usuarios").select("id, email, nombre").eq("email", body.email).execute()
    if not usuario.data:
        raise HTTPException(status_code=404, detail="Correo no registrado")
    u = usuario.data[0]
    pendiente = supabase.table("password_reset_requests").select("id").eq("usuario_id", u["id"]).eq("estado", "pendiente").execute()
    if pendiente.data:
        return {"mensaje": "Ya tienes una solicitud pendiente"}
    supabase.table("password_reset_requests").insert({"usuario_id": u["id"], "email": body.email, "estado": "pendiente"}).execute()
    return {"mensaje": "Solicitud enviada al administrador"}

@app.get("/auth/reset-autorizado")
def check_reset_autorizado(email: str):
    result = supabase.table("password_reset_requests").select("estado").eq("email", email).eq("estado", "autorizado").execute()
    return {"autorizado": len(result.data) > 0}

@app.post("/auth/cambiar-password-temporal")
def cambiar_password_temporal(body: CambiarPassword):
    solicitud = supabase.table("password_reset_requests").select("*").eq("email", body.email).eq("estado", "autorizado").execute()
    if not solicitud.data:
        raise HTTPException(status_code=403, detail="No tienes autorización para cambiar la contraseña")
    s = solicitud.data[0]
    if not verify_password(body.contrasena_temporal, s["contrasena_temporal"]):
        raise HTTPException(status_code=401, detail="Contraseña temporal incorrecta")
    nuevo_hash = hash_password(body.nueva_password)
    supabase.table("usuarios").update({"password_hash": nuevo_hash}).eq("email", body.email).execute()
    supabase.table("password_reset_requests").delete().eq("id", s["id"]).execute()
    return {"mensaje": "Contraseña actualizada correctamente"}

@app.get("/admin/reset-requests")
def listar_reset_requests(current_user=Depends(get_current_user)):
    return supabase.table("password_reset_requests").select("*").eq("estado", "pendiente").order("created_at", desc=True).execute().data

@app.put("/admin/reset-requests/{request_id}/autorizar")
def autorizar_reset(request_id: int, body: ResetAutorizar, current_user=Depends(get_current_user)):
    hashed_temp = hash_password(body.contrasena_temporal)
    supabase.table("password_reset_requests").update({"estado": "autorizado", "contrasena_temporal": hashed_temp}).eq("id", request_id).execute()
    return {"mensaje": "Reset autorizado"}

@app.post("/admin/permisos")
def guardar_permisos(permisos: List[PermisoUpdate], current_user=Depends(get_current_user)):
    for permiso in permisos:
        existe = supabase.table("permisos").select("id") \
            .eq("cargo_id", permiso.cargo_id).eq("funcion_id", permiso.funcion_id).execute()
        data = permiso.dict()
        if existe.data:
            supabase.table("permisos").update(data) \
                .eq("cargo_id", permiso.cargo_id).eq("funcion_id", permiso.funcion_id).execute()
        else:
            supabase.table("permisos").insert(data).execute()
    return {"mensaje": f"{len(permisos)} permisos guardados"}

# ─────────────────────────────────────────────
# LISTADO DE PRECIOS
# ─────────────────────────────────────────────

@app.get("/listado-precios/{contrato_id}")
def get_listado_precios(contrato_id: int, current_user=Depends(get_current_user)):
    all_rows = []
    offset = 0
    while True:
        batch = supabase.table("listado_precios").select("*").eq("contrato_id", contrato_id).order("item_numero").range(offset, offset + 999).execute().data
        all_rows.extend(batch)
        if len(batch) < 1000:
            break
        offset += 1000
    return all_rows

@app.post("/listado-precios/{contrato_id}/bulk")
def bulk_precios(contrato_id: int, items: List[ListadoPrecioItem], current_user=Depends(get_current_user)):
    """Reemplaza todos los precios del contrato con los items del CSV."""
    supabase.table("listado_precios").delete().eq("contrato_id", contrato_id).execute()
    if items:
        rows = [{"contrato_id": contrato_id, **{k: v for k, v in item.dict().items() if v is not None}} for item in items]
        supabase.table("listado_precios").insert(rows).execute()
    return {"mensaje": f"{len(items)} items cargados"}

@app.put("/listado-precios/item/{item_id}")
def update_precio(item_id: int, body: ListadoPrecioItem, current_user=Depends(get_current_user)):
    data = body.dict(exclude_unset=True)
    supabase.table("listado_precios").update(data).eq("id", item_id).execute()
    return {"mensaje": "Item actualizado"}

@app.delete("/listado-precios/item/{item_id}")
def delete_precio(item_id: int, current_user=Depends(get_current_user)):
    supabase.table("listado_precios").delete().eq("id", item_id).execute()
    return {"mensaje": "Item eliminado"}

# ─────────────────────────────────────────────
# PRESUPUESTO
# ─────────────────────────────────────────────

@app.get("/presupuesto/{contrato_id}")
@app.get("/presupuesto/{contrato_id}")
def get_presupuesto(
    contrato_id: int,
    capitulo: Optional[str] = None,
    item: Optional[str] = None,
    tramo: Optional[str] = None,
    calzada: Optional[str] = None,
    papelera: bool = False,
    current_user=Depends(get_current_user)
):
    PAGE = 1000
    all_rows = []
    offset = 0
    while True:
        q = supabase.table("presupuesto").select("*").eq("contrato_id", contrato_id)
        if papelera:
            q = q.eq("dado_de_baja", True)
        else:
            q = q.eq("dado_de_baja", False)
        if capitulo: q = q.eq("capitulo", capitulo)
        if item:     q = q.eq("item", item)
        if tramo:    q = q.eq("tramo", tramo)
        if calzada:  q = q.eq("calzada", calzada)
        batch = q.order("capitulo").order("item").order("pk_id").range(offset, offset + PAGE - 1).execute().data
        all_rows.extend(batch)
        if len(batch) < PAGE:
            break
        offset += PAGE
    return all_rows

@app.get("/presupuesto/{contrato_id}/filtros")
def get_filtros_presupuesto(
    contrato_id: int,
    capitulo: Optional[str] = None,
    item: Optional[str] = None,
    tramo: Optional[str] = None,
    current_user=Depends(get_current_user)
):
    """Devuelve valores únicos para filtros en cascada."""
    q = supabase.table("presupuesto").select("capitulo, item, tramo, calzada").eq("contrato_id", contrato_id)
    if capitulo: q = q.eq("capitulo", capitulo)
    if item:     q = q.eq("item", item)
    if tramo:    q = q.eq("tramo", tramo)
    rows = q.execute().data
    caps    = sorted(set(r["capitulo"] for r in rows if r.get("capitulo")))
    items   = sorted(set(r["item"]     for r in rows if r.get("item")))
    tramos  = sorted(set(r["tramo"]    for r in rows if r.get("tramo")))
    calzadas= sorted(set(r["calzada"]  for r in rows if r.get("calzada")))
    return {"capitulos": caps, "items": items, "tramos": tramos, "calzadas": calzadas}

@app.get("/presupuesto/{contrato_id}/resumen")
def get_resumen_presupuesto(contrato_id: int, current_user=Depends(get_current_user)):
    res  = supabase.table("vista_ppto_resumen").select("*").eq("contrato_id", contrato_id).execute().data
    caps = supabase.table("vista_ppto_por_capitulo").select("*").eq("contrato_id", contrato_id).execute().data
    total = res[0].get("total_ppto", 0) if res else 0
    regs  = res[0].get("total_registros", 0) if res else 0
    return {
        "total_registros": regs,
        "costo_total": total,
        "revisados": 0, "campo": 0, "pendientes": 0,
        "por_capitulo": [{"capitulo": r["capitulo"], "costo": r["presupuesto"], "registros": r["registros"]} for r in caps]
    }

@app.put("/presupuesto/item/{item_id}")
def update_presupuesto_item(item_id: int, body: PresupuestoUpdate, current_user=Depends(get_current_user)):
    data = body.dict(exclude_unset=True)
    dims = {k: data.get(k) for k in ["area_long_nod", "ancho", "espesor"]}
    if any(v is not None for v in dims.values()):
        current = supabase.table("presupuesto").select("area_long_nod, ancho, espesor, vlr_unitario, cant_total").eq("id", item_id).execute().data
        if current:
            c = current[0]
            area  = float(data.get("area_long_nod", c.get("area_long_nod") or 0))
            ancho = float(data.get("ancho",         c.get("ancho")         or 0))
            esp   = float(data.get("espesor",        c.get("espesor")       or 0))
            vlr   = float(data.get("vlr_unitario",   c.get("vlr_unitario")  or 0))
            cant  = round(area * ancho * esp, 2) if (ancho or esp) else round(area, 2)
            data["cant_total"]    = cant
            data["costo_directo"] = round(cant * vlr, 0)
    data["updated_at"] = "now()"
    supabase.table("presupuesto").update(data).eq("id", item_id).execute()
    return {"mensaje": "Registro actualizado"}

@app.put("/presupuesto/item/{item_id}/dar-baja")
def dar_baja_presupuesto(item_id: int, current_user=Depends(get_current_user)):
    """Soft delete: marca el registro como dado de baja y renombra sus layers en CAD."""
    row = supabase.table("presupuesto").select(
        "layer_txt, layer_ent, x_label, y_label, contrato_id, ent_handle, txt_handle, rev_block_handle"
    ).eq("id", item_id).execute().data
    if not row:
        raise HTTPException(status_code=404, detail="Registro no encontrado")
    r = row[0]
    supabase.table("presupuesto").update({
        "dado_de_baja": True,
        "updated_at": "now()"
    }).eq("id", item_id).execute()
    # Cola CAD: renombrar layers con prefijo del_
    if _dwg_activo(r.get("contrato_id")):
        old_lent = r.get("layer_ent") or ""
        old_ltxt = r.get("layer_txt") or ""
        if old_lent and not old_lent.startswith("del_"):
            supabase.table("cad_queue").insert({
                "contrato_id": r["contrato_id"],
                "tipo": "cambiar_layer",
                "estado": "pendiente",
                "payload": {
                    "ent_handle":  r.get("ent_handle") or "",
                    "txt_handle":  r.get("txt_handle") or "",
                    "layer_ent":   f"del_{old_lent}",
                    "layer_txt":   f"del_{old_ltxt}",
                    "color_hex":   "",
                    "rev_block_handle": r.get("rev_block_handle") or "",
                    "layoff": True
                }
            }).execute()
        # Actualizar layers en la tabla presupuesto también
        supabase.table("presupuesto").update({
            "layer_ent": f"del_{old_lent}" if old_lent and not old_lent.startswith("del_") else old_lent,
            "layer_txt": f"del_{old_ltxt}" if old_ltxt and not old_ltxt.startswith("del_") else old_ltxt,
        }).eq("id", item_id).execute()
    return {"ok": True}

@app.put("/presupuesto/item/{item_id}/restaurar")
def restaurar_presupuesto(item_id: int, current_user=Depends(get_current_user)):
    """Restaura un registro dado de baja: quita del_ de layers y reactiva en CAD."""
    row = supabase.table("presupuesto").select(
        "layer_txt, layer_ent, x_label, y_label, contrato_id, ent_handle, txt_handle, color_hex"
    ).eq("id", item_id).execute().data
    if not row:
        raise HTTPException(status_code=404, detail="Registro no encontrado")
    r = row[0]
    supabase.table("presupuesto").update({
        "dado_de_baja": False,
        "updated_at": "now()"
    }).eq("id", item_id).execute()
    # Cola CAD: restaurar layers quitando prefijo del_
    if _dwg_activo(r.get("contrato_id")):
        old_lent = r.get("layer_ent") or ""
        old_ltxt = r.get("layer_txt") or ""
        new_lent = old_lent[4:] if old_lent.startswith("del_") else old_lent
        new_ltxt = old_ltxt[4:] if old_ltxt.startswith("del_") else old_ltxt
        if new_lent:
            supabase.table("cad_queue").insert({
                "contrato_id": r["contrato_id"],
                "tipo": "cambiar_layer",
                "estado": "pendiente",
                "payload": {
                    "ent_handle": r.get("ent_handle") or "",
                    "txt_handle": r.get("txt_handle") or "",
                    "layer_ent":  new_lent,
                    "layer_txt":  new_ltxt,
                    "color_hex":  r.get("color_hex") or "",
                    "layoff": False
                }
            }).execute()
        supabase.table("presupuesto").update({
            "layer_ent": new_lent,
            "layer_txt": new_ltxt,
        }).eq("id", item_id).execute()
    return {"ok": True}

@app.post("/presupuesto/{contrato_id}/bulk")
def bulk_presupuesto(contrato_id: int, items: List[PresupuestoRow], mode: str = "append", current_user=Depends(get_current_user)):
    """Importa registros de presupuesto. mode=replace elimina todo primero, mode=append agrega."""
    if mode == "replace":
        supabase.table("presupuesto").delete().eq("contrato_id", contrato_id).execute()
    if not items:
        return {"insertados": 0}
    BATCH = 500
    rows = []
    for item in items:
        d = {k: v for k, v in item.dict().items() if v is not None}
        d["contrato_id"] = contrato_id
        rows.append(d)
    insertados = 0
    for i in range(0, len(rows), BATCH):
        try:
            supabase.table("presupuesto").insert(rows[i:i+BATCH]).execute()
            insertados += len(rows[i:i+BATCH])
        except Exception as e:
            for row in rows[i:i+BATCH]:
                try:
                    supabase.table("presupuesto").insert(row).execute()
                    insertados += 1
                except Exception:
                    pass
    registrar_log(current_user, "IMPORTAR", "PRESUPUESTO", "presupuesto_bulk", str(contrato_id),
        {"contrato_id": contrato_id, "mode": mode, "registros_insertados": insertados})
    return {"insertados": insertados}

@app.put("/presupuesto/{contrato_id}/bulk-recalcular")
def bulk_recalcular(contrato_id: int, body: PresupuestoBulkRecalc, current_user=Depends(get_current_user)):
    if not body.ids:
        raise HTTPException(status_code=400, detail="No hay registros seleccionados")
    dims_map = {d.id: d for d in (body.dims or [])}
    # Traer también handles y layers para cad_queue
    rows = supabase.table("presupuesto").select(
        "id, area_long_nod, ancho, espesor, cant_total, vlr_unitario, ent_handle, txt_handle, layer_ent, layer_txt, color_hex, competencia"
    ).in_("id", body.ids).execute().data
    for r in rows:
        rid = r["id"]
        dim = dims_map.get(rid)
        ancho   = (dim.ancho   if dim and dim.ancho   is not None else None) or r.get("ancho")   or 1
        espesor = (dim.espesor if dim and dim.espesor is not None else None) or r.get("espesor") or 1
        area    = r.get("area_long_nod") or 0
        vlr     = body.vlr_unitario if body.vlr_unitario is not None else (r.get("vlr_unitario") or 0)
        # Recalcular cant_total con las nuevas dimensiones si hay dims
        if dim and (dim.ancho is not None or dim.espesor is not None):
            cant = round(float(area) * float(ancho) * float(espesor), 4)
            data_ancho   = {"ancho": ancho, "espesor": espesor}
        else:
            cant = r.get("cant_total") or 0
            data_ancho   = {}
        costo = round(float(cant) * float(vlr), 0)
        data  = {"cant_total": cant, "costo_directo": costo, "updated_at": "now()", **data_ancho}
        if body.capitulo    is not None: data["capitulo"]    = body.capitulo
        if body.item        is not None: data["item"]        = body.item
        if body.descripcion is not None: data["descripcion"] = body.descripcion
        if body.vlr_unitario is not None: data["vlr_unitario"] = body.vlr_unitario
        # Reconstruir id_pol si cambia el ítem
        new_id_pol = None
        if body.item is not None:
            rows_idpol = supabase.table("presupuesto").select("id_pol").eq("id", rid).execute().data
            old_id_pol = (rows_idpol[0].get("id_pol") or "") if rows_idpol else ""
            # Extraer sufijo: todo lo que va después del 
            #  "._"
            if "._" in old_id_pol:
                sufijo = old_id_pol[old_id_pol.index("._"):]   # ej: "._1558"
            else:
                sufijo = f"._{rid}"
            new_id_pol = f"{body.item}{sufijo}"   # ej: "8.01._1558"
            data["id_pol"] = new_id_pol
        supabase.table("presupuesto").update(data).eq("id", rid).execute()
        # ── Encolar operación CAD si cambió ítem/capítulo ──────────────────
        if (body.capitulo is not None or body.item is not None) and _dwg_activo(contrato_id):
            nuevo_cap  = body.capitulo or ""
            nuevo_item = body.item     or ""
            comp       = r.get("competencia") or ""
            cap6       = nuevo_cap.replace(".", "")[:5]
            new_layer_ent = f"{cap6}_{comp}_{nuevo_item}"
            new_layer_txt = f"txt_{cap6}_{comp}_{nuevo_item}"
            payload_cad = {
                "ent_handle":  r.get("ent_handle") or "",
                "txt_handle":  r.get("txt_handle") or "",
                "layer_ent":   new_layer_ent,
                "layer_txt":   new_layer_txt,
                "color_hex":   r.get("color_hex") or "",
            }
            if new_id_pol:
                payload_cad["new_text"] = new_id_pol
            supabase.table("cad_queue").insert({
                "contrato_id": contrato_id,
                "tipo": "cambiar_layer",
                "estado": "pendiente",
                "payload": payload_cad
            }).execute()
    registrar_log(current_user, "RECALCULAR", "PRESUPUESTO", "presupuesto_bulk", str(contrato_id),
        {"contrato_id": contrato_id, "cantidad_registros": len(rows),
         "capitulo": body.capitulo, "item": body.item})
    return {"actualizados": len(rows)}

@app.put("/presupuesto/{contrato_id}/bulk-estado")
def bulk_estado(contrato_id: int, body: PresupuestoBulkEstado, current_user=Depends(get_current_user)):
    if not body.ids:
        raise HTTPException(status_code=400, detail="No hay registros seleccionados")
    # Traer x_label, y_label, layer_txt para cad_queue
    rows_info = supabase.table("presupuesto").select("id, x_label, y_label, layer_txt, rev_block_handle"
        ).in_("id", body.ids).execute().data
    info_map = {r["id"]: r for r in rows_info}
    es_interventoria = current_user.get("rol_nombre") == "Interventoría"
    sellar = body.revisado == "Verificado" and es_interventoria
    nombre_usuario = current_user.get("nombre") or current_user.get("email") or "Usuario"
    for rid in body.ids:
        data_upd = {"revisado": body.revisado, "updated_at": "now()"}
        if sellar:
            data_upd["sellado"] = True
        if body.revisado == "Verificado":
            data_upd["validado_por"] = nombre_usuario
            data_upd["validado_en"]  = datetime.utcnow().isoformat()
        elif body.revisado != "Verificado":
            # Si cambia de Verificado a otro estado, limpiar
            data_upd["validado_por"] = None
            data_upd["validado_en"]  = None
        supabase.table("presupuesto").update(data_upd).eq("id", rid).execute()
        # ── Encolar operación CAD si DWG conectado ─────────────────────────
        if _dwg_activo(contrato_id):
            r = info_map.get(rid, {})
            if r.get("x_label") and r.get("y_label"):
                supabase.table("cad_queue").insert({
                    "contrato_id": contrato_id,
                    "tipo": "insertar_bloque",
                    "estado": "pendiente",
                    "payload": {
                        "presupuesto_id":    rid,
                        "x_label":           r["x_label"],
                        "y_label":           r["y_label"],
                        "estado":            body.revisado,
                        "layer_txt":         r.get("layer_txt") or "",
                        "rev_block_handle":  r.get("rev_block_handle") or "",
                    }
                }).execute()
    registrar_log(current_user, "VALIDAR", "PRESUPUESTO", "presupuesto_bulk", str(contrato_id),
        {"contrato_id": contrato_id, "cantidad_registros": len(body.ids), "estado": body.revisado})            
    return {"actualizados": len(body.ids)}

# ─────────────────────────────────────────────
# CAD QUEUE
# ─────────────────────────────────────────────

@app.get("/cobro/{contrato_id}/exportar-capitulo")
def exportar_capitulo_excel(contrato_id: int, capitulo: str, current_user=Depends(get_current_user)):
    try:
        from openpyxl import Workbook
        from openpyxl.styles import (Font, PatternFill, Alignment, Border, Side,
                                      GradientFill)
        from openpyxl.utils import get_column_letter
        from openpyxl.drawing.image import Image as XLImage
        import tempfile, os

        # ── 1. Datos ────────────────────────────────────────────────────────
        def fetch_all(tabla, cols, filtros={}):
            acc, offset = [], 0
            while True:
                q = supabase.table(tabla).select(cols).eq("contrato_id", contrato_id).eq("capitulo", capitulo)
                for k, v in filtros.items():
                    q = q.eq(k, v)
                batch = q.range(offset, offset + 999).execute().data
                acc.extend(batch)
                if len(batch) < 1000: break
                offset += 1000
            return acc

        ppto_rows = fetch_all("presupuesto", "*")
        cobro_rows = fetch_all("cobro", "*")

        contrato_info = supabase.table("contratos").select(
            "numero, contratista, interventoria, logo_contratista, logo_interventoria"
        ).eq("id", contrato_id).single().execute().data or {}

        now_str = datetime.now().strftime("%d/%m/%Y %H:%M")
        cap_nombre = capitulo
        contratista = contrato_info.get("contratista", "")
        logo_cont_url = contrato_info.get("logo_contratista", "")
        logo_int_url  = contrato_info.get("logo_interventoria", "")

        # ── 2. Helpers de estilo ─────────────────────────────────────────────
        COLOR_HEADER   = "1A3A5C"
        COLOR_TITLE    = "0D2137"
        COLOR_DEVOL    = "C0392B"
        COLOR_PORCOBR  = "1E8449"
        COLOR_HIST     = "7D6608"
        COLOR_TOTAL    = "154360"
        COLOR_ITEM_H   = "117A65"
        COLOR_ALT      = "EBF5FB"
        COLOR_DEVOL_BG = "FADBD8"
        COLOR_COBR_BG  = "D5F5E3"

        def header_style(ws, row, col, val, bg=COLOR_HEADER, fg="FFFFFF", bold=True, size=10, wrap=False, halign="center"):
            c = ws.cell(row=row, column=col, value=val)
            c.font = Font(name="Arial", bold=bold, color=fg, size=size)
            c.fill = PatternFill("solid", fgColor=bg)
            c.alignment = Alignment(horizontal=halign, vertical="center", wrap_text=wrap)
            return c

        def data_cell(ws, row, col, val, bold=False, color="000000", bg=None, halign="right", fmt=None):
            c = ws.cell(row=row, column=col, value=val)
            c.font = Font(name="Arial", bold=bold, color=color, size=9)
            if bg:
                c.fill = PatternFill("solid", fgColor=bg)
            c.alignment = Alignment(horizontal=halign, vertical="center")
            if fmt:
                c.number_format = fmt
            return c

        def thin_border():
            s = Side(style="thin", color="CCCCCC")
            return Border(left=s, right=s, top=s, bottom=s)

        def apply_border(ws, min_row, max_row, min_col, max_col):
            for r in range(min_row, max_row + 1):
                for c in range(min_col, max_col + 1):
                    ws.cell(r, c).border = thin_border()

        def set_col_widths(ws, widths):
            for i, w in enumerate(widths, 1):
                ws.column_dimensions[get_column_letter(i)].width = w

        def add_logo(ws, url, anchor):
            if not url: return
            try:
                import tempfile, os
                r = req_http.get(url, timeout=4)
                if r.status_code != 200: return
                ext = ".png" if "png" in r.headers.get("content-type","") else ".jpg"
                tmp = tempfile.mktemp(suffix=ext)
                with open(tmp, "wb") as f: f.write(r.content)
                img = XLImage(tmp)
                img.height = 45; img.width = 110
                ws.add_image(img, anchor)
                try: os.remove(tmp)
                except: pass
            except: pass

        def titulo_hoja(ws, titulo, subtitulo, ncols):
            ws.row_dimensions[1].height = 55
            ws.row_dimensions[2].height = 18
            ws.row_dimensions[3].height = 8
            ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=ncols)
            c = ws.cell(1, 1, titulo)
            c.font = Font(name="Arial", bold=True, size=10, color="FFFFFF")
            c.fill = PatternFill("solid", fgColor=COLOR_TITLE)
            c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
            ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=ncols)
            c2 = ws.cell(2, 1, subtitulo)
            c2.font = Font(name="Arial", size=9, color="7F8C8D")
            c2.alignment = Alignment(horizontal="center")
            # logos
            add_logo(ws, logo_int_url,  "A1")
            add_logo(ws, logo_cont_url, f"{get_column_letter(ncols-1)}1")

        def fmt_cop(n):
            return n  # guardamos el número, el formato de celda hace el resto

        # ── 3. Agregar por ítem ──────────────────────────────────────────────
        from collections import defaultdict

        # Presupuesto agregado por ítem
        p_item = defaultdict(lambda: {"cant": 0, "costo": 0, "desc": "", "vlr_unit": 0})
        for r in ppto_rows:
            it = r.get("item", "")
            p_item[it]["cant"]     += r.get("cant_total") or 0
            p_item[it]["costo"]    += r.get("costo_directo") or 0
            if not p_item[it]["desc"]:
                p_item[it]["desc"]     = r.get("descripcion", "")
                p_item[it]["vlr_unit"] = r.get("vlr_unitario") or 0

        # Cobro agregado por ítem
        c_item = defaultdict(lambda: {"cant": 0, "costo": 0, "desc": ""})
        for r in cobro_rows:
            it = r.get("item", "")
            c_item[it]["cant"]  += r.get("cantidad") or r.get("longitud") or 0
            c_item[it]["costo"] += r.get("costo_directo") or 0
            if not c_item[it]["desc"]:
                c_item[it]["desc"] = r.get("descripcion", "")

        # Completar descripción faltante desde cobro cuando ppto no tiene el ítem
        for it in c_item:
            if not p_item[it]["desc"] and c_item[it]["desc"]:
                p_item[it]["desc"] = c_item[it]["desc"]

        all_items = sorted(set(list(p_item.keys()) + list(c_item.keys())))

        def get_estado(p_cant, p_costo, c_cant, c_costo):
            # Cobro Histórico: sin presupuesto calculado pero con cobro — delta positivo
            if p_cant == 0 and p_costo == 0 and c_cant > 0:
                return "Cobro Histórico", round(c_cant, 4), round(c_costo, 0)
            d_cant  = round(p_cant  - c_cant,  4)
            d_costo = round(p_costo - c_costo, 0)
            if d_costo < 0:
                return "Devolución", d_cant, d_costo
            return "Por cobrar", d_cant, d_costo

        # ── 4. Workbook ──────────────────────────────────────────────────────
        wb = Workbook()

        # ══════════════════════════════════════════════════════════════════════
        # HOJA 1 — Resumen Capítulo
        # ══════════════════════════════════════════════════════════════════════
        ws1 = wb.active
        ws1.title = "Resumen Capítulo"
        ws1.sheet_view.showGridLines = False
        NCOLS1 = 9

        titulo_hoja(ws1, f"RESUMEN POR CAPÍTULO — {cap_nombre}",
                    f"Generado: {now_str}   |   {contratista}", NCOLS1)

        # Cabeceras
        hdrs1 = ["Ítem","Descripción","Cant. ClaraCore","Costo ClaraCore",
                 "Cant. Cobrada","Costo Cobrado","Δ Cantidad","Δ Costo","Estado"]
        ws1.row_dimensions[4].height = 30
        for i, h in enumerate(hdrs1, 1):
            header_style(ws1, 4, i, h, wrap=True)

        # Datos
        row = 5
        tot_p_cant=tot_p_costo=tot_c_cant=tot_c_costo=tot_d_cant=tot_d_costo = 0
        for it in all_items:
            p = p_item[it]; c = c_item[it]
            estado, d_cant, d_costo = get_estado(p["cant"], p["costo"], c["cant"], c["costo"])
            alt = (row % 2 == 0)
            bg = None
            if estado == "Devolución":    bg = COLOR_DEVOL_BG
            elif estado == "Cobro Histórico": bg = "FEF9E7"
            else:                          bg = COLOR_COBR_BG if alt else None

            estado_color = (COLOR_DEVOL if estado=="Devolución"
                            else COLOR_HIST if estado=="Cobro Histórico"
                            else COLOR_PORCOBR)

            data_cell(ws1, row, 1, it,          bold=True, halign="left", bg=bg)
            data_cell(ws1, row, 2, p["desc"],   halign="left", bg=bg)
            data_cell(ws1, row, 3, round(p["cant"],2),  fmt="#,##0.00", bg=bg)
            data_cell(ws1, row, 4, round(p["costo"],0), fmt='$#,##0', bg=bg)
            data_cell(ws1, row, 5, round(c["cant"],2),  fmt="#,##0.00", bg=bg)
            data_cell(ws1, row, 6, round(c["costo"],0), fmt='$#,##0', bg=bg)
            dc = data_cell(ws1, row, 7, round(d_cant,2),  fmt="#,##0.00", bg=bg, bold=True)
            dc.font = Font(name="Arial", bold=True, size=9,
                           color=COLOR_DEVOL if d_cant < 0 else COLOR_PORCOBR)
            dd = data_cell(ws1, row, 8, round(d_costo,0), fmt='$#,##0', bg=bg, bold=True)
            dd.font = Font(name="Arial", bold=True, size=9,
                           color=COLOR_DEVOL if d_costo < 0 else COLOR_PORCOBR)
            est_c = data_cell(ws1, row, 9, estado, bold=True, halign="center", bg=bg)
            est_c.font = Font(name="Arial", bold=True, size=9, color=estado_color)

            tot_p_cant  += p["cant"];  tot_p_costo  += p["costo"]
            tot_c_cant  += c["cant"];  tot_c_costo  += c["costo"]
            tot_d_cant  += d_cant;     tot_d_costo  += d_costo
            row += 1

        # Fila totales
        ws1.row_dimensions[row].height = 22
        for col in range(1, NCOLS1+1):
            c_cell = ws1.cell(row, col)
            c_cell.fill = PatternFill("solid", fgColor=COLOR_TOTAL)
            c_cell.font = Font(name="Arial", bold=True, color="FFFFFF", size=10)
            c_cell.alignment = Alignment(horizontal="center", vertical="center")
        ws1.cell(row, 1, "TOTALES CAPÍTULO")
        ws1.cell(row, 3, round(tot_p_cant, 2)).number_format  = "#,##0.00"
        ws1.cell(row, 4, round(tot_p_costo,0)).number_format  = '$#,##0'
        ws1.cell(row, 5, round(tot_c_cant, 2)).number_format  = "#,##0.00"
        ws1.cell(row, 6, round(tot_c_costo,0)).number_format  = '$#,##0'
        ws1.cell(row, 7, round(tot_d_cant, 2)).number_format  = "#,##0.00"
        ws1.cell(row, 8, round(tot_d_costo,0)).number_format  = '$#,##0'

        apply_border(ws1, 4, row, 1, NCOLS1)
        set_col_widths(ws1, [10, 42, 14, 16, 14, 16, 12, 16, 14])
        ws1.freeze_panes = "A5"

        # ══════════════════════════════════════════════════════════════════════
        # HOJAS POR ÍTEM — análisis por PK_ID
        # ══════════════════════════════════════════════════════════════════════
        for it in all_items:
            p = p_item[it]; c = c_item[it]
            estado, _, _ = get_estado(p["cant"], p["costo"], c["cant"], c["costo"])
            if estado == "Cobro Histórico": continue  # excluir

            # Agregar por pk_id
            p_pk = defaultdict(lambda: {"cant":0,"costo":0})
            c_pk = defaultdict(lambda: {"cant":0,"costo":0})
            for r in ppto_rows:
                if r.get("item") != it: continue
                pk = str(r.get("pk_id") or r.get("id_pol") or "S/N")
                p_pk[pk]["cant"]  += r.get("cant_total") or 0
                p_pk[pk]["costo"] += r.get("costo_directo") or 0
            for r in cobro_rows:
                if r.get("item") != it: continue
                pk = str(r.get("pk_id") or "S/N")
                c_pk[pk]["cant"]  += r.get("longitud") or r.get("cantidad") or 0
                c_pk[pk]["costo"] += r.get("costo_directo") or 0

            all_pks = sorted(set(list(p_pk.keys()) + list(c_pk.keys())))

            # Separar por cobrar y devolución
            porcobrar = [(pk, p_pk[pk], c_pk[pk]) for pk in all_pks
                         if round(p_pk[pk]["costo"] - c_pk[pk]["costo"], 0) >= 0
                         and not (p_pk[pk]["cant"]==0 and c_pk[pk]["cant"]>0)]
            devolucion= [(pk, p_pk[pk], c_pk[pk]) for pk in all_pks
                         if round(p_pk[pk]["costo"] - c_pk[pk]["costo"], 0) < 0
                         and not (p_pk[pk]["cant"]==0 and c_pk[pk]["cant"]>0)]

            sname = f"Item {it}"[:31]
            ws = wb.create_sheet(sname)
            ws.sheet_view.showGridLines = False
            NCOLS = 7

            desc_it = p_item[it]["desc"] or c_item[it].get("desc", "")
            titulo_hoja(ws, f"ANÁLISIS DE COBRO — {it}  |  {desc_it}",
                        f"{cap_nombre}   |   Generado: {now_str}", NCOLS)

            # Resumen ítem (fila 4)
            ws.row_dimensions[4].height = 20
            sum_hdrs = ["Cant. ClaraCore","Costo ClaraCore","Cant. Cobrada",
                        "Costo Cobrado","Δ Cantidad","Δ Costo"]
            
            for i, h in enumerate(sum_hdrs, 1):
                header_style(ws, 4, i, h, bg=COLOR_ITEM_H)
            ws.row_dimensions[5].height = 18
            d_cant_it = round(p["cant"] - c["cant"], 2)
            d_cost_it = round(p["costo"]- c["costo"], 0)
            vals = [round(p["cant"],2), round(p["costo"],0),
                    round(c["cant"],2), round(c["costo"],0),
                    d_cant_it, d_cost_it]
            fmts = ["#,##0.00","$#,##0","#,##0.00","$#,##0","#,##0.00","$#,##0"]
            for i,(v,f) in enumerate(zip(vals,fmts),1):
                cc = ws.cell(5, i, v); cc.number_format = f
                cc.font = Font(name="Arial", bold=True, size=10,
                               color=COLOR_DEVOL if v < 0 else COLOR_PORCOBR)
                cc.alignment = Alignment(horizontal="center", vertical="center")

            def write_pk_section(ws, start_row, titulo_sec, datos, bg_sec):
                ws.row_dimensions[start_row].height = 20
                ws.merge_cells(start_row=start_row, start_column=1,
                               end_row=start_row, end_column=NCOLS)
                c = ws.cell(start_row, 1, titulo_sec)
                c.font = Font(name="Arial", bold=True, size=10, color="FFFFFF")
                c.fill = PatternFill("solid", fgColor=
                    COLOR_DEVOL if "DEVOLUCIÓN" in titulo_sec else COLOR_PORCOBR)
                c.alignment = Alignment(horizontal="left", vertical="center")
                start_row += 1

                # Headers
                hdrs = ["PK_Id","Cant.ClaraCore","Costo ClaraCore",
                        "Cant.Cobrada","Costo Cobrado","Δ Cant","Δ Costo"]
                for i, h in enumerate(hdrs, 1):
                    header_style(ws, start_row, i, h, bg=COLOR_HEADER)
                start_row += 1

                tot_pc=tot_cc=tot_pco=tot_cco=tot_dc=tot_dco = 0
                for pk, pp, cp in datos:
                    dc = round(pp["cant"]  - cp["cant"],  2)
                    dco= round(pp["costo"] - cp["costo"], 0)
                    alt = (start_row % 2 == 0)
                    bg = bg_sec if alt else None
                    data_cell(ws, start_row, 1, pk,             halign="left",   bg=bg, bold=True)
                    data_cell(ws, start_row, 2, round(pp["cant"],2),  fmt="#,##0.00", bg=bg)
                    data_cell(ws, start_row, 3, round(pp["costo"],0), fmt='$#,##0',   bg=bg)
                    data_cell(ws, start_row, 4, round(cp["cant"],2),  fmt="#,##0.00", bg=bg)
                    data_cell(ws, start_row, 5, round(cp["costo"],0), fmt='$#,##0',   bg=bg)
                    cc2 = data_cell(ws, start_row, 6, dc,  fmt="#,##0.00", bg=bg, bold=True)
                    cc2.font = Font(name="Arial",bold=True,size=9,
                                    color=COLOR_DEVOL if dc<0 else COLOR_PORCOBR)
                    cc3 = data_cell(ws, start_row, 7, dco, fmt='$#,##0', bg=bg, bold=True)
                    cc3.font = Font(name="Arial",bold=True,size=9,
                                    color=COLOR_DEVOL if dco<0 else COLOR_PORCOBR)
                    tot_pc+=pp["cant"]; tot_cc+=cp["cant"]
                    tot_pco+=pp["costo"]; tot_cco+=cp["costo"]
                    tot_dc+=dc; tot_dco+=dco
                    start_row += 1

                # Subtotal
                for col in range(1, NCOLS+1):
                    ws.cell(start_row,col).fill = PatternFill("solid", fgColor="2C3E50")
                    ws.cell(start_row,col).font = Font(name="Arial",bold=True,color="FFFFFF",size=9)
                    ws.cell(start_row,col).alignment = Alignment(horizontal="center",vertical="center")
                ws.cell(start_row,1,"SUBTOTAL")
                ws.cell(start_row,2,round(tot_pc,2)).number_format  = "#,##0.00"
                ws.cell(start_row,3,round(tot_pco,0)).number_format = '$#,##0'
                ws.cell(start_row,4,round(tot_cc,2)).number_format  = "#,##0.00"
                ws.cell(start_row,5,round(tot_cco,0)).number_format = '$#,##0'
                ws.cell(start_row,6,round(tot_dc,2)).number_format  = "#,##0.00"
                ws.cell(start_row,7,round(tot_dco,0)).number_format = '$#,##0'
                return start_row + 2

            cur_row = 7
            if porcobrar:
                total_pc = sum(pp["costo"]-cp["costo"] for _,pp,cp in porcobrar)
                cur_row = write_pk_section(ws, cur_row,
                    f"POR COBRAR | Total: +${round(total_pc):,}", porcobrar, "D5F5E3")
            if devolucion:
                total_dv = sum(pp["costo"]-cp["costo"] for _,pp,cp in devolucion)
                cur_row = write_pk_section(ws, cur_row,
                    f"DEVOLUCIÓN | Total: -${abs(round(total_dv)):,}", devolucion, "FADBD8")

            apply_border(ws, 4, cur_row-2, 1, NCOLS)
            set_col_widths(ws, [14,14,16,14,16,12,16])
            ws.freeze_panes = "A8"

        # ══════════════════════════════════════════════════════════════════════
        # HOJA — Base Cobro (write_only para velocidad)
        # ══════════════════════════════════════════════════════════════════════
        ws_c = wb.create_sheet("Base Cobro")
        if cobro_rows:
            from openpyxl.styles import NamedStyle
            cols_c = list(cobro_rows[0].keys())
            hdr_font = Font(name="Arial", bold=True, color="FFFFFF", size=8)
            hdr_fill = PatternFill("solid", fgColor=COLOR_HEADER)
            hdr_aln  = Alignment(horizontal="center", vertical="center")
            # Header
            hdr_row = []
            for h in cols_c:
                c = ws_c.cell(row=1, column=1)  # dummy — usamos append
                hdr_row.append(str(h).upper())
            ws_c.append(hdr_row)
            for ci, h in enumerate(cols_c, 1):
                cell = ws_c.cell(1, ci)
                cell.font = hdr_font; cell.fill = hdr_fill; cell.alignment = hdr_aln
            # Datos sin formato alternado — mucho más rápido
            for row_d in cobro_rows:
                ws_c.append([row_d.get(col) for col in cols_c])
            ws_c.freeze_panes = "A2"
            for i in range(1, len(cols_c)+1):
                ws_c.column_dimensions[get_column_letter(i)].width = 13

        # ══════════════════════════════════════════════════════════════════════
        # HOJA — ClaraCore Data (Presupuesto)
        # ══════════════════════════════════════════════════════════════════════
        ws_p = wb.create_sheet("ClaraCore Data")
        if ppto_rows:
            cols_p = list(ppto_rows[0].keys())
            ws_p.append([str(h).upper() for h in cols_p])
            for ci, h in enumerate(cols_p, 1):
                cell = ws_p.cell(1, ci)
                cell.font = Font(name="Arial", bold=True, color="FFFFFF", size=8)
                cell.fill = PatternFill("solid", fgColor=COLOR_TITLE)
                cell.alignment = Alignment(horizontal="center", vertical="center")
            for row_d in ppto_rows:
                ws_p.append([row_d.get(col) for col in cols_p])
            ws_p.freeze_panes = "A2"
            for i in range(1, len(cols_p)+1):
                ws_p.column_dimensions[get_column_letter(i)].width = 13

        # ── 5. Stream ────────────────────────────────────────────────────────
        buf = io.BytesIO()
        wb.save(buf)
        buf.seek(0)

        import urllib.parse
        cap_safe = urllib.parse.quote(capitulo[:40])
        filename  = f"ClaraCore_{cap_safe}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"

        return StreamingResponse(
            buf,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": f'attachment; filename="{filename}"'}
        )

    except Exception as ex:
        raise HTTPException(status_code=500, detail=str(ex))

@app.post("/cad-queue/{contrato_id}/heartbeat")
def cad_heartbeat(contrato_id: int, current_user=Depends(get_current_user)):
    """SicoeCAD llama esto cada 3s para indicar que el DWG está abierto."""
    usuario_id = current_user.get("id") if isinstance(current_user, dict) else current_user.id
    _dwg_sessions[(contrato_id, usuario_id)] = time.time()
    return {"ok": True, "ts": time.time()}

@app.get("/cad-queue/{contrato_id}/estado")
def cad_estado(contrato_id: int, current_user=Depends(get_current_user)):
    """ClaraCore web consulta si hay DWG enlazado."""
    enlazado = _dwg_activo(contrato_id)
    return {"enlazado": enlazado}

@app.get("/cad-queue/{contrato_id}/pendientes")
def cad_pendientes(contrato_id: int, current_user=Depends(get_current_user)):
    """SicoeCAD descarga las operaciones pendientes."""
    rows = supabase.table("cad_queue").select("*") \
        .eq("contrato_id", contrato_id).eq("estado", "pendiente") \
        .order("id").limit(50).execute().data
    return rows

@app.post("/cad-queue/{contrato_id}/highlight-registro")
def highlight_registro(contrato_id: int, body: dict, current_user=Depends(get_current_user)):
    """Encola highlight de entidad+texto de un registro de presupuesto."""
    presupuesto_id = body.get("presupuesto_id")
    if not presupuesto_id:
        raise HTTPException(status_code=400, detail="presupuesto_id requerido")
    row = supabase.table("presupuesto").select("ent_handle, txt_handle, x_label, y_label").eq("id", presupuesto_id).single().execute().data
    if not row or not row.get("ent_handle"):
        raise HTTPException(status_code=404, detail="Registro sin ent_handle")
    payload = {
        "ent_handle": row.get("ent_handle", ""),
        "txt_handle": row.get("txt_handle", ""),
        "x_label":    row.get("x_label", 0),
        "y_label":    row.get("y_label", 0),
    }
    usuario_id = current_user["id"] if isinstance(current_user, dict) else current_user.id
    supabase.table("cad_queue").insert({
        "contrato_id":  contrato_id,
        "tipo":         "highlight_registro",
        "payload":      payload,
        "usuario_id":   usuario_id,
        "procesado":    False,
    }).execute()
    return {"ok": True}

@app.post("/cad-queue/{contrato_id}/zoom-pkid")
def zoom_pkid(contrato_id: int, pk_id: str, current_user=Depends(get_current_user)):
    """Encola operación de zoom a un PK_ID en AutoCAD."""
    rows = supabase.table("presupuesto").select(
        "ent_handle, x_label, y_label"
    ).eq("contrato_id", contrato_id).eq("pk_id", pk_id).limit(1).execute().data
    if not rows:
        raise HTTPException(status_code=404, detail="PK_ID no encontrado en presupuesto")
    r = rows[0]
    ent_handle = r.get("ent_handle") or ""
    x = r.get("x_label") or 0
    y = r.get("y_label") or 0
    if not ent_handle and (x == 0 and y == 0):
        raise HTTPException(status_code=404, detail="Sin coordenadas para este PK_ID")
    supabase.table("cad_queue").insert({
        "contrato_id": contrato_id,
        "tipo": "zoom_pkid",
        "estado": "pendiente",
        "payload": {
            "pk_id":      pk_id,
            "ent_handle": ent_handle,
            "x":          x,
            "y":          y,
            "radio":      30
        }
    }).execute()
    return {"ok": True, "pk_id": pk_id}

@app.put("/cad-queue/{op_id}/procesado")
def cad_procesado(op_id: int, body: CadQueueProcesado, current_user=Depends(get_current_user)):
    """SicoeCAD marca la operación como procesada."""
    supabase.table("cad_queue").update({
        "estado": "procesado",
        "processed_at": datetime.utcnow().isoformat()
    }).eq("id", op_id).execute()
    # Si la op era insertar_bloque, guardar el handle del bloque en presupuesto
    if body.presupuesto_id and body.rev_block_handle:
        supabase.table("presupuesto").update({
            "rev_block_handle": body.rev_block_handle
        }).eq("id", body.presupuesto_id).execute()
    return {"ok": True}

# ─────────────────────────────────────────────
# COBRO
# ─────────────────────────────────────────────

@app.get("/cobro/{contrato_id}/pkid-tabla")
def pkid_tabla(contrato_id: int, capitulo: str = None, item: str = None, current_user=Depends(get_current_user)):
    """Tabla comparativa detallada por PK_ID con cantidades"""
    try:
        q_c = supabase.table("cobro").select("pk_id, costo_directo, longitud, cantidad").eq("contrato_id", contrato_id)
        q_p = supabase.table("presupuesto").select("pk_id, cant_total, costo_directo, descripcion").eq("contrato_id", contrato_id)
        if item:
            q_c = q_c.eq("item", item)
            q_p = q_p.eq("item", item)
        elif capitulo:
            q_c = q_c.eq("capitulo", capitulo)
            q_p = q_p.eq("capitulo", capitulo)
        def paginate(q):
            all_rows = []; offset = 0
            while True:
                batch = q.range(offset, offset + 999).execute().data or []
                all_rows.extend(batch)
                if len(batch) < 1000: break
                offset += 1000
            return all_rows
        cobros = paginate(q_c)
        ppto   = paginate(q_p)
        agg_p = {}
        for r in ppto:
            k = r.get("pk_id") or "(sin pk)"
            if k not in agg_p: agg_p[k] = {"cant": 0.0, "costo": 0.0, "desc": ""}
            agg_p[k]["cant"]  += float(r.get("cant_total") or 0)
            agg_p[k]["costo"] += float(r.get("costo_directo") or 0)
            if not agg_p[k]["desc"] and r.get("descripcion"):
                agg_p[k]["desc"] = r.get("descripcion", "")
        agg_c = {}
        for r in cobros:
            k = r.get("pk_id") or "(sin pk)"
            if k not in agg_c: agg_c[k] = {"cant": 0.0, "costo": 0.0}
            agg_c[k]["cant"]  += float(r.get("cantidad") or r.get("longitud") or 0)
            agg_c[k]["costo"] += float(r.get("costo_directo") or 0)
        keys = sorted(set(list(agg_p.keys()) + list(agg_c.keys())), key=lambda x: str(x))
        rows = []
        for k in keys:
            p = agg_p.get(k, {"cant": 0.0, "costo": 0.0})
            c = agg_c.get(k, {"cant": 0.0, "costo": 0.0})
            rows.append({"pk_id": k, "cant_ppto": p["cant"], "costo_ppto": p["costo"],
                         "cant_sicoe": c["cant"], "costo_sicoe": c["costo"],
                         "delta_cant": round(p["cant"] - c["cant"], 2),
                         "delta_costo": round(p["costo"] - c["costo"], 0),
                         "descripcion": p.get("desc", "")})
        por_cobrar = sum(r["delta_costo"] for r in rows if r["delta_costo"] > 0)
        devolucion = sum(abs(r["delta_costo"]) for r in rows if r["delta_costo"] < 0)
        # Descripción del ítem — consulta dedicada, no depende de los polígonos
        desc_item = ""
        if item:
            d = supabase.table("presupuesto").select("descripcion").eq("contrato_id", contrato_id).eq("item", item).not_.is_("descripcion", "null").limit(1).execute().data
            if d: desc_item = d[0].get("descripcion") or ""
        return {"rows": rows, "por_cobrar": por_cobrar, "devolucion": devolucion, "descripcion_item": desc_item}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/cobro/{contrato_id}/pkid-detalle")
def pkid_detalle(contrato_id: int, pk_id: str = None, item: str = None, capitulo: str = None, current_user=Depends(get_current_user)):
    """Filas individuales de ppto y cobro para un PK_ID específico."""
    try:
        q_p = supabase.table("presupuesto").select(
            "id_pol, no_inicio, no_final, cant_total, costo_directo, descripcion, item"
        ).eq("contrato_id", contrato_id)
        q_c = supabase.table("cobro").select(
            "registro, tramo_inicio, tramo_final, cantidad, longitud, costo_directo, descripcion, item, acta, calzada"
        ).eq("contrato_id", contrato_id)
        if pk_id:
            q_p = q_p.eq("pk_id", pk_id)
            q_c = q_c.eq("pk_id", pk_id)
        if item:
            q_p = q_p.eq("item", item)
            q_c = q_c.eq("item", item)
        elif capitulo:
            q_p = q_p.eq("capitulo", capitulo)
            q_c = q_c.eq("capitulo", capitulo)
        ppto  = q_p.execute().data or []
        cobro = q_c.execute().data or []
        cant_ppto  = sum(float(r.get("cant_total") or 0) for r in ppto)
        costo_ppto = sum(float(r.get("costo_directo") or 0) for r in ppto)
        cant_cobro  = sum(float(r.get("cantidad") or r.get("longitud") or 0) for r in cobro)
        costo_cobro = sum(float(r.get("costo_directo") or 0) for r in cobro)
        return {
            "ppto":  ppto,
            "cobro": cobro,
            "totales": {
                "cant_ppto":   round(cant_ppto, 2),
                "costo_ppto":  round(costo_ppto, 0),
                "cant_cobro":  round(cant_cobro, 2),
                "costo_cobro": round(costo_cobro, 0),
                "delta_cant":  round(cant_ppto - cant_cobro, 2),
                "delta_costo": round(costo_ppto - costo_cobro, 0),
            }
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/cobro/{contrato_id}/drill")
def drill_comparativo(contrato_id: int, capitulo: str = None, item: str = None, current_user=Depends(get_current_user)):
    """Drill comparativo presupuesto vs cobro por capitulo→item→pk_id"""
    def fetch_filtered(tabla, dest, capitulo, item):
        acc, offset = [], 0
        while True:
            q = supabase.table(tabla).select(dest).eq("contrato_id", contrato_id)
            if capitulo: q = q.eq("capitulo", capitulo)
            if item:     q = q.eq("item", item)
            batch = q.range(offset, offset + 999).execute().data
            acc.extend(batch)
            if len(batch) < 1000:
                break
            offset += 1000
        return acc

    cobros = fetch_filtered("cobro",       "capitulo, item, pk_id, costo_directo, cantidad, longitud, descripcion", capitulo, item)
    ppto   = fetch_filtered("presupuesto", "capitulo, item, pk_id, costo_directo, cant_total, descripcion",          capitulo, item)

    campo = "pk_id" if (capitulo and item) else ("item" if capitulo else "capitulo")

    agg_p = {}; agg_c = {}; agg_p_cant = {}; agg_c_cant = {}; desc_map = {}
    for r in ppto:
        k = r.get(campo) or "(sin valor)"
        agg_p[k] = agg_p.get(k, 0) + (r.get("costo_directo") or 0)
        agg_p_cant[k] = agg_p_cant.get(k, 0) + (r.get("cant_total") or 0)
        if campo == "item" and r.get("descripcion") and k not in desc_map:
            desc_map[k] = r.get("descripcion", "")
    for r in cobros:
        k = r.get(campo) or "(sin valor)"
        agg_c[k] = agg_c.get(k, 0) + (r.get("costo_directo") or 0)
        agg_c_cant[k] = agg_c_cant.get(k, 0) + (r.get("cantidad") or r.get("longitud") or 0)
        if campo == "item" and r.get("descripcion") and k not in desc_map:
            desc_map[k] = r.get("descripcion", "")

    keys = sorted(set(list(agg_p.keys()) + list(agg_c.keys())), key=lambda x: str(x))
    result = []
    for k in keys:
        p = agg_p.get(k, 0); c = agg_c.get(k, 0)
        result.append({"nombre": k, "descripcion": desc_map.get(k, ""), "presupuesto": p, "cobrado": c, "delta": p - c, "pct": round(c/p*100,1) if p else 0, "cant_ppto": agg_p_cant.get(k, 0), "cant_cobro": agg_c_cant.get(k, 0)})
    return {"campo": campo, "items": result}

@app.get("/cobro/{contrato_id}/analisis-items")
def get_analisis_items(contrato_id: int, current_user=Depends(get_current_user)):
    """Todos los ítems con comparativo ppto vs cobro para análisis de desviaciones"""
    cobros, ppto = [], []
    for tabla, dest in [
        ("cobro", "capitulo, item, costo_directo, cantidad, longitud"),
        ("presupuesto", "capitulo, item, descripcion, costo_directo, cant_total")
    ]:
        acc, offset = [], 0
        while True:
            batch = supabase.table(tabla).select(dest).eq("contrato_id", contrato_id).range(offset, offset + 999).execute().data
            acc.extend(batch)
            if len(batch) < 1000: break
            offset += 1000
        if tabla == "cobro": cobros = acc
        else: ppto = acc

    agg_p = {}; agg_c = {}; agg_p_cant = {}; agg_c_cant = {}; desc_map = {}; cap_map = {}
    for r in ppto:
        k = r.get("item") or "(sin item)"
        agg_p[k] = agg_p.get(k, 0) + (r.get("costo_directo") or 0)
        agg_p_cant[k] = agg_p_cant.get(k, 0) + (r.get("cant_total") or 0)
        if r.get("descripcion") and k not in desc_map: desc_map[k] = r["descripcion"]
        if k not in cap_map: cap_map[k] = r.get("capitulo") or ""
    for r in cobros:
        k = r.get("item") or "(sin item)"
        agg_c[k] = agg_c.get(k, 0) + (r.get("costo_directo") or 0)
        agg_c_cant[k] = agg_c_cant.get(k, 0) + (r.get("cantidad") or r.get("longitud") or 0)

    keys2 = sorted(set(list(agg_p.keys()) + list(agg_c.keys())))
    result2 = []
    for k in keys2:
        p = agg_p.get(k, 0); c = agg_c.get(k, 0)
        result2.append({
            "nombre": k, "capitulo": cap_map.get(k, ""), "descripcion": desc_map.get(k, ""),
            "presupuesto": p, "cobrado": c, "delta": p - c,
            "pct": round(c / p * 100, 1) if p else 0,
            "cant_ppto": agg_p_cant.get(k, 0), "cant_cobro": agg_c_cant.get(k, 0),
        })
    return {"items": result2}

@app.get("/presupuesto/{contrato_id}/analisis-liquidacion")
def get_analisis_liquidacion(contrato_id: int, nivel: str = "item", current_user=Depends(get_current_user)):
    """Compara cobro vs cantidades recalculadas (tipo_ejecucion='O') para fase de liquidación."""
    cobros, recalc = [], []
    # Cobro: toda la tabla cobro del contrato
    offset = 0
    while True:
        batch = supabase.table("cobro").select("capitulo, item, costo_directo, cantidad, longitud").eq("contrato_id", contrato_id).range(offset, offset + 999).execute().data
        cobros.extend(batch)
        if len(batch) < 1000: break
        offset += 1000
    # Recalculado: presupuesto con tipo_ejecucion = 'O' (Obra ejecutada)
    offset = 0
    while True:
        batch = supabase.table("presupuesto").select("capitulo, item, descripcion, costo_directo, cant_total").eq("contrato_id", contrato_id).eq("tipo_ejecucion", "Obra Ejecutada").range(offset, offset + 999).execute().data
        recalc.extend(batch)
        if len(batch) < 1000: break
        offset += 1000

    agg_r = {}; agg_c = {}; agg_r_cant = {}; agg_c_cant = {}; desc_map = {}; cap_map = {}
    for r in recalc:
        k = r.get("item") or "(sin item)"
        agg_r[k] = agg_r.get(k, 0) + (r.get("costo_directo") or 0)
        agg_r_cant[k] = agg_r_cant.get(k, 0) + (r.get("cant_total") or 0)
        if r.get("descripcion") and k not in desc_map: desc_map[k] = r["descripcion"]
        if k not in cap_map: cap_map[k] = r.get("capitulo") or ""
    for r in cobros:
        k = r.get("item") or "(sin item)"
        agg_c[k] = agg_c.get(k, 0) + (r.get("costo_directo") or 0)
        agg_c_cant[k] = agg_c_cant.get(k, 0) + (r.get("cantidad") or r.get("longitud") or 0)
        if k not in cap_map and r.get("capitulo"): cap_map[k] = r["capitulo"]

    # Si nivel=capitulo, re-agregar por capítulo
    if nivel == "capitulo":
        cap_r = {}; cap_c = {}; cap_r_cant = {}; cap_c_cant = {}; cap_desc = {}
        for k in agg_r:
            cap = cap_map.get(k, "(sin capítulo)")
            cap_r[cap] = cap_r.get(cap, 0) + agg_r[k]
            cap_r_cant[cap] = cap_r_cant.get(cap, 0) + agg_r_cant.get(k, 0)
        for k in agg_c:
            cap = cap_map.get(k, "(sin capítulo)")
            cap_c[cap] = cap_c.get(cap, 0) + agg_c[k]
            cap_c_cant[cap] = cap_c_cant.get(cap, 0) + agg_c_cant.get(k, 0)
        agg_r = cap_r; agg_c = cap_c; agg_r_cant = cap_r_cant; agg_c_cant = cap_c_cant
        cap_map = {k: k for k in agg_r}

    UMBRAL = 20_000_000
    keys = sorted(set(list(agg_r.keys()) + list(agg_c.keys())))
    result = []
    for k in keys:
        r_val = agg_r.get(k, 0); c_val = agg_c.get(k, 0)
        r_cant = agg_r_cant.get(k, 0); c_cant = agg_c_cant.get(k, 0)
        delta_costo = r_val - c_val
        if r_cant == 0 and c_val > 0:
            categoria = "EJECUCION"
        elif c_val > r_val and (c_val - r_val) > UMBRAL:
            categoria = "SUPERCOBRO"
        elif c_val > r_val and (c_val - r_val) <= UMBRAL:
            categoria = "DEVOLUCION"
        elif r_val > c_val:
            categoria = "POR_COBRAR"
        else:
            categoria = "EQUILIBRIO"
        cap_val = k if nivel == "capitulo" else cap_map.get(k, "")
        result.append({
            "nombre": k, "capitulo": cap_val, "descripcion": desc_map.get(k, ""),
            "recalculado": r_val, "cobrado": c_val, "delta_costo": delta_costo,
            "pct": round(c_val / r_val * 100, 1) if r_val else 0,
            "cant_recalc": r_cant, "cant_cobro": c_cant, "delta_cant": r_cant - c_cant,
            "categoria": categoria,
        })
    return {"items": result}

@app.get("/cobro/{contrato_id}/pkid-colores-liquidacion")
def get_pkid_colores_liquidacion(
    contrato_id: int,
    capitulo: Optional[str] = None,
    item: Optional[str] = None,
    current_user=Depends(get_current_user)
):
    """Colores PK_ID: cobro vs recalculado (tipo_ejecucion='O') para mini-mapa liquidación."""
    q_c = supabase.table("cobro").select("pk_id, costo_directo").eq("contrato_id", contrato_id)
    q_r = supabase.table("presupuesto").select("pk_id, costo_directo").eq("contrato_id", contrato_id).eq("tipo_ejecucion", "obra ejecutada")
    if item:
        q_c = q_c.eq("item", item)
        q_r = q_r.eq("item", item)
    elif capitulo:
        q_c = q_c.eq("capitulo", capitulo)
        q_r = q_r.eq("capitulo", capitulo)
    cobro = q_c.execute().data
    recalc = q_r.execute().data
    cobro_agg = {}
    for r in cobro:
        k = str(r.get("pk_id") or "").strip()
        if k: cobro_agg[k] = cobro_agg.get(k, 0) + (r.get("costo_directo") or 0)
    recalc_agg = {}
    for r in recalc:
        k = str(r.get("pk_id") or "").strip()
        if k: recalc_agg[k] = recalc_agg.get(k, 0) + (r.get("costo_directo") or 0)
    UMBRAL = 20_000_000
    result = {}
    for pk in set(list(cobro_agg.keys()) + list(recalc_agg.keys())):
        c = cobro_agg.get(pk, 0)
        r2 = recalc_agg.get(pk, 0)
        if r2 == 0 and c > 0:
            categoria = "EJECUCION"
        elif c > r2 and (c - r2) > UMBRAL:
            categoria = "SUPERCOBRO"
        elif c > r2 and (c - r2) <= UMBRAL:
            categoria = "DEVOLUCION"
        elif r2 > c:
            categoria = "POR_COBRAR"
        else:
            categoria = "EQUILIBRIO"
        result[pk] = {"cobrado": c, "recalculado": r2, "pct": round(c / r2 * 100, 1) if r2 else 0, "categoria": categoria}
    return result
def get_cobro(
    contrato_id: int,
    capitulo: Optional[str] = None,
    item: Optional[str] = None,
    acta: Optional[int] = None,
    calzada: Optional[str] = None,
    current_user=Depends(get_current_user)
):
    q = supabase.table("cobro").select("*").eq("contrato_id", contrato_id)
    if capitulo: q = q.eq("capitulo", capitulo)
    if item:     q = q.eq("item", item)
    if acta:     q = q.eq("acta", acta)
    if calzada:  q = q.eq("calzada", calzada)
    PAGE = 1000
    all_rows = []
    offset = 0
    while True:
        batch = q.order("acta").order("capitulo").order("item").range(offset, offset + PAGE - 1).execute().data
        all_rows.extend(batch)
        if len(batch) < PAGE:
            break
        offset += PAGE
    return all_rows

@app.get("/cobro/{contrato_id}/chart")
def get_cobro_chart(
    contrato_id: int,
    nivel: str = "capitulo",
    capitulo: Optional[str] = None,
    item: Optional[str] = None,
    current_user=Depends(get_current_user)
):
    """Devuelve datos agregados para gráficos con fallback directo a tabla cobro."""
    try:
        if nivel == "capitulo":
            raw = supabase.table("vista_cobro_por_capitulo_detalle").select("*").eq("contrato_id", contrato_id).execute().data
            rows = [{"capitulo": r.get("capitulo"), "costo": r.get("cobrado") or r.get("costo") or 0, "count": r.get("count", 0)} for r in raw]
        elif nivel == "item":
            q = supabase.table("vista_cobro_por_item").select("*").eq("contrato_id", contrato_id)
            if capitulo: q = q.eq("capitulo", capitulo)
            rows = q.execute().data
            rows = [{"item": r.get("item"), "descripcion": r.get("descripcion"), "costo": r.get("cobrado") or r.get("costo") or 0, "count": r.get("count", 0)} for r in rows]
        elif nivel == "acta":
            raw = supabase.table("vista_cobro_por_acta").select("*").eq("contrato_id", contrato_id).execute().data
            rows = [{"acta": r.get("acta"), "costo": r.get("cobrado") or r.get("costo") or 0, "count": r.get("count", 0)} for r in raw]
        elif nivel == "calzada":
            raw = supabase.table("vista_cobro_por_calzada").select("*").eq("contrato_id", contrato_id).execute().data
            rows = [{"calzada": r.get("calzada"), "costo": r.get("cobrado") or r.get("costo") or 0, "count": r.get("count", 0)} for r in raw]
        else:
            rows = []
    except Exception:
        raw = []; offset = 0
        sel = "item, descripcion, capitulo, costo_directo" if nivel == "item" else f"{nivel}, costo_directo"
        q_fb = supabase.table("cobro").select(sel).eq("contrato_id", contrato_id)
        if capitulo and nivel == "item":
            q_fb = q_fb.eq("capitulo", capitulo)
        while True:
            batch = q_fb.range(offset, offset+999).execute().data
            raw.extend(batch)
            if len(batch) < 1000: break
            offset += 1000
        agg = {}
        for r in raw:
            k = r.get(nivel) or "(sin valor)"
            if k not in agg: agg[k] = {nivel: k, "costo": 0, "count": 0}
            agg[k]["costo"] += r.get("costo_directo") or 0
            agg[k]["count"] += 1
        rows = list(agg.values())
    return sorted(rows, key=lambda r: str(r.get(nivel) or ""))

@app.get("/cobro/{contrato_id}/resumen")
def get_resumen_cobro(contrato_id: int, current_user=Depends(get_current_user)):
    res      = supabase.table("vista_cobro_resumen").select("*").eq("contrato_id", contrato_id).execute().data
    por_acta = supabase.table("vista_cobro_por_acta").select("*").eq("contrato_id", contrato_id).execute().data
    por_cap  = supabase.table("vista_cobro_por_capitulo").select("*").eq("contrato_id", contrato_id).execute().data
    total    = res[0].get("total_cobrado", 0) if res else 0
    actas    = sorted(set(r["acta"] for r in por_acta if r.get("acta")))
    # Comparativo por capítulo
    ppto_caps = {r["capitulo"]: r["presupuesto"] for r in
                 supabase.table("vista_ppto_por_capitulo").select("*").eq("contrato_id", contrato_id).execute().data}
    cobro_caps = {r["capitulo"]: r.get("cobrado") or r.get("costo") or 0 for r in por_cap}
    caps = sorted(set(list(ppto_caps.keys()) + list(cobro_caps.keys())))
    comparativo = [{"capitulo": c, "presupuesto": ppto_caps.get(c,0), "cobrado": cobro_caps.get(c,0),
                    "delta": ppto_caps.get(c,0)-cobro_caps.get(c,0),
                    "consumo_pct": round(cobro_caps.get(c,0)/ppto_caps.get(c,0)*100,1) if ppto_caps.get(c,0) else 0}
                   for c in caps]
    ppto_total = sum(ppto_caps.values())
    return {
        "total_presupuesto": ppto_total,
        "total_cobrado": total,
        "delta": ppto_total - total,
        "consumo_pct": round(total/ppto_total*100,1) if ppto_total else 0,
        "actas": actas,
        "comparativo_capitulos": comparativo,
        "por_acta": [{"acta": r["acta"], "cobrado": r.get("cobrado") or r.get("costo") or 0} for r in por_acta]
    }

@app.get("/cobro/{contrato_id}/pkid-colores")
def get_pkid_colores(contrato_id: int, current_user=Depends(get_current_user)):
    """Devuelve % cobro por PK_ID para colorear el plano semáforo."""
    cobro  = supabase.table("cobro").select("pk_id, costo_directo").eq("contrato_id", contrato_id).execute().data
    ppto   = supabase.table("presupuesto").select("pk_id, costo_directo").eq("contrato_id", contrato_id).execute().data
    cobro_agg = {}
    for r in cobro:
        k = str(r.get("pk_id") or "").strip()
        if k: cobro_agg[k] = cobro_agg.get(k, 0) + (r.get("costo_directo") or 0)
    ppto_agg = {}
    for r in ppto:
        k = str(r.get("pk_id") or "").strip()
        if k: ppto_agg[k] = ppto_agg.get(k, 0) + (r.get("costo_directo") or 0)
    result = {}
    for pk in set(list(cobro_agg.keys()) + list(ppto_agg.keys())):
        c = cobro_agg.get(pk, 0)
        p = ppto_agg.get(pk, 0)
        result[pk] = {
            "cobrado": c,
            "presupuesto": p,
            "pct": round(c / p * 100, 1) if p else 0,
            "sobrecosto": c > p
        }
    return result

@app.get("/presupuesto/{contrato_id}/pkid-colores")
def get_ppto_pkid_colores(
    contrato_id: int,
    capitulo: Optional[str] = None,
    item: Optional[str] = None,
    current_user=Depends(get_current_user)
):
    """Colores PK_ID para el mini-mapa del módulo presupuesto."""
    q = supabase.table("presupuesto").select("pk_id, costo_directo").eq("contrato_id", contrato_id)
    if item:     q = q.eq("item", item)
    elif capitulo: q = q.eq("capitulo", capitulo)
    rows = q.execute().data
    agg = {}
    for r in rows:
        k = str(r.get("pk_id") or "").strip()
        if k: agg[k] = agg.get(k, 0) + (r.get("costo_directo") or 0)
    if not agg: return {}
    max_costo = max(agg.values()) or 1
    result = {}
    for pk, costo in agg.items():
        pct = round(costo / max_costo * 100, 1)
        result[pk] = {"costo": costo, "pct": pct, "activo": True}
    return result

@app.get("/cobro/{contrato_id}/pkid-colores-drill")
def get_pkid_colores_drill(
    contrato_id: int,
    capitulo: Optional[str] = None,
    item: Optional[str] = None,
    current_user=Depends(get_current_user)
):
    """Colores PK_ID filtrados por capítulo/ítem para el mini-mapa del dashboard."""
    q_c = supabase.table("cobro").select("pk_id, costo_directo").eq("contrato_id", contrato_id)
    q_p = supabase.table("presupuesto").select("pk_id, costo_directo").eq("contrato_id", contrato_id)
    if item:
        q_c = q_c.eq("item", item)
        q_p = q_p.eq("item", item)
    elif capitulo:
        q_c = q_c.eq("capitulo", capitulo)
        q_p = q_p.eq("capitulo", capitulo)
    try:
        cobro = q_c.execute().data
    except Exception:
        cobro = []
    try:
        ppto = q_p.execute().data
    except Exception:
        ppto = []
    cobro_agg = {}
    for r in cobro:
        k = str(r.get("pk_id") or "").strip()
        if k: cobro_agg[k] = cobro_agg.get(k, 0) + (r.get("costo_directo") or 0)
    ppto_agg = {}
    for r in ppto:
        k = str(r.get("pk_id") or "").strip()
        if k: ppto_agg[k] = ppto_agg.get(k, 0) + (r.get("costo_directo") or 0)
    result = {}
    for pk in set(list(cobro_agg.keys()) + list(ppto_agg.keys())):
        c = cobro_agg.get(pk, 0)
        p = ppto_agg.get(pk, 0)
        result[pk] = {
            "cobrado": c,
            "presupuesto": p,
            "pct": round(c / p * 100, 1) if p else 0,
            "sobrecosto": c > p
        }
    return result

@app.get("/cobro/{contrato_id}/filtros")
def get_filtros_cobro(
    contrato_id: int,
    capitulo: Optional[str] = None,
    item: Optional[str] = None,
    current_user=Depends(get_current_user)
):
    q = supabase.table("cobro").select("capitulo, item, acta, calzada").eq("contrato_id", contrato_id)
    if capitulo: q = q.eq("capitulo", capitulo)
    if item:     q = q.eq("item", item)
    rows = q.execute().data
    return {
        "capitulos": sorted(set(r["capitulo"] for r in rows if r.get("capitulo"))),
        "items":     sorted(set(r["item"]     for r in rows if r.get("item"))),
        "actas":     sorted(set(r["acta"]     for r in rows if r.get("acta"))),
        "calzadas":  sorted(set(r["calzada"]  for r in rows if r.get("calzada"))),
    }

@app.delete("/cobro/{contrato_id}/clear")
def clear_cobro(contrato_id: int, current_user=Depends(get_current_user)):
    # Borrar en batches de 1000 para no timeout en Supabase free tier
    while True:
        ids = supabase.table("cobro").select("id").eq("contrato_id", contrato_id).limit(1000).execute().data
        if not ids:
            break
        id_list = [r["id"] for r in ids]
        supabase.table("cobro").delete().in_("id", id_list).execute()
    return {"ok": True}

@app.post("/cobro/{contrato_id}/bulk")
def bulk_cobro(contrato_id: int, items: List[CobroRow], current_user=Depends(get_current_user)):
    if not items:
        return {"insertados": 0}
    BATCH = 500
    all_rows = []
    for row in items:
        d = {}
        for k, v in row.dict().items():
            if v is None:
                continue
            if k == "fecha":
                continue
            # Limpiar saltos de línea en campos de texto
            if isinstance(v, str):
                v = v.replace('\n', ' ').replace('\r', ' ').replace('\t', ' ').strip()
                v = ' '.join(v.split())  # colapsar espacios múltiples
            d[k] = v
        d["contrato_id"] = contrato_id
        all_rows.append(d)
    insertados = 0
    for i in range(0, len(all_rows), BATCH):
        try:
            supabase.table("cobro").insert(all_rows[i:i+BATCH]).execute()
            insertados += len(all_rows[i:i+BATCH])
        except Exception:
            # Si falla el batch, insertar fila por fila para no perder todo
            for row in all_rows[i:i+BATCH]:
                try:
                    supabase.table("cobro").insert(row).execute()
                    insertados += 1
                except Exception:
                    pass  # omitir fila problemática y continuar
    registrar_log(current_user, "IMPORTAR", "COBRO", "cobro_bulk", str(contrato_id),
        {"contrato_id": contrato_id, "registros_insertados": insertados})    
    return {"insertados": insertados}


# ═══════════════════════════════════════════════════════════════════════════════
# COMENTARIOS
# ═══════════════════════════════════════════════════════════════════════════════

class ComentarioBulk(BaseModel):
    presupuesto_ids: List[int]
    tipo: str        # dims | item_capitulo | validacion
    mensaje: str
    usuario_nombre: str

class RespuestaCreate(BaseModel):
    mensaje: str
    usuario_nombre: str

@app.post("/presupuesto/{contrato_id}/comentarios/bulk")
def crear_comentarios_bulk(contrato_id: int, body: ComentarioBulk, current_user=Depends(get_current_user)):
    rows = [{"presupuesto_id": pid, "tipo": body.tipo, "mensaje": body.mensaje,
             "usuario_nombre": body.usuario_nombre} for pid in body.presupuesto_ids]
    supabase.table("comentarios").insert(rows).execute()
    return {"creados": len(rows)}

@app.get("/presupuesto/{contrato_id}/comentarios-resumen")
def comentarios_resumen(contrato_id: int, ids: str, current_user=Depends(get_current_user)):
    id_list = [int(x) for x in ids.split(",") if x.strip().isdigit()]
    if not id_list:
        return {}
    rows = supabase.table("comentarios").select(
        "id, presupuesto_id, tipo, parent_id"
    ).in_("presupuesto_id", id_list).execute().data
    id_to_tipo = {r["id"]: r["tipo"] for r in rows}
    result = {}
    for r in rows:
        pid = r["presupuesto_id"]
        if pid not in result:
            result[pid] = {
                "dims":          {"count": 0, "replies": False},
                "item_capitulo": {"count": 0, "replies": False},
                "validacion":    {"count": 0, "replies": False},
            }
        tipo = r["tipo"]
        if r["parent_id"] is None:
            result[pid][tipo]["count"] += 1
        else:
            result[pid][tipo]["replies"] = True
    return result

@app.get("/presupuesto/{presupuesto_id}/comentarios")
def get_comentarios(presupuesto_id: int, tipo: str, current_user=Depends(get_current_user)):
    rows = supabase.table("comentarios").select("*").eq(
        "presupuesto_id", presupuesto_id).eq("tipo", tipo).order("created_at").execute().data
    roots = [r for r in rows if r["parent_id"] is None]
    children = {}
    for r in rows:
        if r["parent_id"]:
            children.setdefault(r["parent_id"], []).append(r)
    for root in roots:
        root["respuestas"] = children.get(root["id"], [])
    return roots

@app.post("/comentarios/{comentario_id}/respuesta")
def responder_comentario(comentario_id: int, body: RespuestaCreate, current_user=Depends(get_current_user)):
    parent = supabase.table("comentarios").select("presupuesto_id, tipo").eq("id", comentario_id).execute().data
    if not parent:
        raise HTTPException(status_code=404, detail="Comentario no encontrado")
    p = parent[0]
    supabase.table("comentarios").insert({
        "presupuesto_id": p["presupuesto_id"],
        "tipo":           p["tipo"],
        "mensaje":        body.mensaje,
        "usuario_nombre": body.usuario_nombre,
        "parent_id":      comentario_id
    }).execute()
    return {"ok": True}
# ─────────────────────────────────────────────
# LOGS
# ─────────────────────────────────────────────

@app.get("/logs")
def get_logs(
    usuario_id:   Optional[int] = None,
    modulo:       Optional[str] = None,
    accion:       Optional[str] = None,
    fecha_desde:  Optional[str] = None,
    fecha_hasta:  Optional[str] = None,
    limit:        int = 100,
    offset:       int = 0,
    current_user=Depends(get_current_user)
):
    """Consulta logs con filtros. Solo para Desarrollador y Administrador."""
    q = supabase.table("logs").select("*").order("created_at", desc=True)
    if usuario_id:  q = q.eq("usuario_id", usuario_id)
    if modulo:      q = q.eq("modulo", modulo)
    if accion:      q = q.eq("accion", accion)
    if fecha_desde: q = q.gte("created_at", fecha_desde)
    if fecha_hasta: q = q.lte("created_at", fecha_hasta + "T23:59:59")
    q = q.range(offset, offset + limit - 1)
    return q.execute().data

@app.get("/logs/usuarios-lista")
def get_logs_usuarios(current_user=Depends(get_current_user)):
    """Lista de usuarios que tienen logs — para el selector de filtros."""
    rows = supabase.table("logs").select("usuario_id, usuario_nombre, cargo_nombre").execute().data
    vistos = {}
    for r in rows:
        uid = r.get("usuario_id")
        if uid and uid not in vistos:
            vistos[uid] = {"id": uid, "nombre": r.get("usuario_nombre",""), "cargo": r.get("cargo_nombre","")}
    return list(vistos.values())

@app.get("/logs/entidad/{entidad_tipo}/{entidad_id}")
def get_logs_entidad(entidad_tipo: str, entidad_id: str, current_user=Depends(get_current_user)):
    """Historial completo de una entidad específica."""
    return supabase.table("logs").select("*") \
        .eq("entidad_tipo", entidad_tipo) \
        .eq("entidad_id", entidad_id) \
        .order("created_at", desc=False) \
        .execute().data

# ─────────────────────────────────────────────
# NOTIFICACIONES
# ─────────────────────────────────────────────

class NotificacionCreate(BaseModel):
    destinatario_id: Optional[int] = None  # None = broadcast a todos
    asunto: str
    mensaje: str
    tipo: str = "MENSAJE_DIRECTO"  # MENSAJE_DIRECTO | BROADCAST | SISTEMA | SOPORTE
    modulo: Optional[str] = None
    contrato_id: Optional[int] = None
    entidad_tipo: Optional[str] = None
    entidad_id: Optional[str] = None
    padre_id: Optional[int] = None

@app.post("/notificaciones")
def crear_notificacion(body: NotificacionCreate, current_user=Depends(get_current_user)):
    """Envía una notificación. Si destinatario_id es None y tipo=BROADCAST, envía a todos."""
    uid = int(current_user.get("sub", 0))
    nombre = current_user.get("nombre") or current_user.get("email", "")

    if body.tipo == "BROADCAST":
        # Enviar a todos los usuarios activos excepto el remitente
        usuarios = supabase.table("usuarios").select("id").eq("activo", True).execute().data
        rows = []
        for u in usuarios:
            if u["id"] == uid:
                continue
            rows.append({
                "remitente_id":     uid,
                "remitente_nombre": nombre,
                "destinatario_id":  u["id"],
                "asunto":           body.asunto,
                "mensaje":          body.mensaje,
                "tipo":             body.tipo,
                "modulo":           body.modulo,
                "contrato_id":      body.contrato_id,
                "entidad_tipo":     body.entidad_tipo,
                "entidad_id":       body.entidad_id,
                "padre_id":         body.padre_id,
            })
        if rows:
            supabase.table("notificaciones").insert(rows).execute()
        registrar_log(current_user, "BROADCAST", "NOTIFICACIONES", "notificacion", None,
            {"asunto": body.asunto, "destinatarios": len(rows)})
        return {"enviados": len(rows)}
    else:
        row = {
            "remitente_id":     uid,
            "remitente_nombre": nombre,
            "destinatario_id":  body.destinatario_id,
            "asunto":           body.asunto,
            "mensaje":          body.mensaje,
            "tipo":             body.tipo,
            "modulo":           body.modulo,
            "contrato_id":      body.contrato_id,
            "entidad_tipo":     body.entidad_tipo,
            "entidad_id":       body.entidad_id,
            "padre_id":         body.padre_id,
        }
        result = supabase.table("notificaciones").insert(row).execute()

        # Si es respuesta, marcar el mensaje raíz como no leído para el destinatario
        if body.padre_id:
            try:
                supabase.table("notificaciones") \
                    .update({"leido": False}) \
                    .eq("id", body.padre_id) \
                    .execute()
            except: pass

        registrar_log(current_user, "ENVIAR", "NOTIFICACIONES", "notificacion",
            str(result.data[0]["id"]) if result.data else None,
            {"asunto": body.asunto, "destinatario_id": body.destinatario_id, "tipo": body.tipo})
        return result.data[0] if result.data else {}

@app.get("/notificaciones/recibidas")
def get_notificaciones_recibidas(
    solo_no_leidas: bool = False,
    limit: int = 50,
    offset: int = 0,
    current_user=Depends(get_current_user)
):
    """Notificaciones recibidas por el usuario actual."""
    uid = int(current_user.get("sub", 0))
    q = supabase.table("notificaciones").select("*") \
        .eq("destinatario_id", uid) \
        .order("created_at", desc=True)
    if solo_no_leidas:
        q = q.eq("leido", False)
    q = q.range(offset, offset + limit - 1)
    return q.execute().data

@app.get("/notificaciones/enviadas")
def get_notificaciones_enviadas(
    limit: int = 50,
    offset: int = 0,
    current_user=Depends(get_current_user)
):
    """Notificaciones enviadas por el usuario actual."""
    uid = int(current_user.get("sub", 0))
    return supabase.table("notificaciones").select("*") \
        .eq("remitente_id", uid) \
        .order("created_at", desc=True) \
        .range(offset, offset + limit - 1) \
        .execute().data

@app.get("/notificaciones/no-leidas-count")
def get_no_leidas_count(current_user=Depends(get_current_user)):
    """Conteo de notificaciones no leídas — solo mensajes raíz."""
    uid = int(current_user.get("sub", 0))
    result = supabase.table("notificaciones").select("id", count="exact") \
        .eq("destinatario_id", uid) \
        .eq("leido", False) \
        .is_("padre_id", "null") \
        .execute()
    return {"count": result.count or 0}

@app.get("/notificaciones/{notif_id}/hilo")
def get_hilo(notif_id: int, current_user=Depends(get_current_user)):
    """Devuelve el hilo completo de una notificación (padre + respuestas)."""
    # Primero encontrar el padre raíz
    notif = supabase.table("notificaciones").select("*").eq("id", notif_id).execute().data
    if not notif: raise HTTPException(status_code=404, detail="No encontrada")
    padre_id = notif[0].get("padre_id") or notif_id
    # Marcar como leída
    uid = int(current_user.get("sub", 0))
    supabase.table("notificaciones").update({"leido": True, "leido_at": "now()"}) \
        .eq("id", notif_id).eq("destinatario_id", uid).execute()
    # Traer padre + todas las respuestas
    padre = supabase.table("notificaciones").select("*").eq("id", padre_id).execute().data
    respuestas = supabase.table("notificaciones").select("*") \
        .eq("padre_id", padre_id).order("created_at").execute().data
    return {"hilo": padre + respuestas}

@app.put("/notificaciones/{notif_id}/leida")
def marcar_leida(notif_id: int, current_user=Depends(get_current_user)):
    uid = int(current_user.get("sub", 0))
    supabase.table("notificaciones").update({"leido": True, "leido_at": "now()"}) \
        .eq("id", notif_id).eq("destinatario_id", uid).execute()
    return {"ok": True}

@app.get("/notificaciones/usuarios-destinatarios")
def get_usuarios_destinatarios(current_user=Depends(get_current_user)):
    """Lista de usuarios activos para el selector de destinatario."""
    uid = int(current_user.get("sub", 0))
    rows = supabase.table("usuarios").select("id, nombre, apellidos, cargo_id") \
        .eq("activo", True).execute().data
    cargos = {c["id"]: c["nombre"] for c in supabase.table("cargos").select("id, nombre").execute().data}
    return [
        {"id": r["id"], "nombre": f"{r['nombre']} {r.get('apellidos','')}", "cargo": cargos.get(r.get("cargo_id"), "")}
        for r in rows if r["id"] != uid
    ]
